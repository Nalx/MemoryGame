package vista;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import model.Card;
import model.Deck;
import model.SceneThread;
import controller.newMouseListener;
/**
 * Dibuixa tota la partida del joc segons la dificultat que li correspongui i el tipus de partida
 */

public class Scene extends JPanel {
	//A jpFitxes hi ha les Cartes (espai reservat per la imatge de fitxa) de la partida.
	private Card[] jlFitxes = new Card[20];
	private Deck deck;
	//El layered Pane s'utiliitza per poder treballar amb diverses capes
	private JLabel jlSuperior;
	private Card labelAux;
	private int dificultat;
	private int saltDeFila1;
	private int saltDeFila2;
	private int saltDeFila3;
	private int espaiEntreCartes;
	//***** Variables per inicialitzar l'escena
	private int nImageScaleX;
	private int nImageScaleY;
	private int nImageGridPosX;
	private int nImageGridPosY;
	private int numCartes;
	private int nPoints;
	private double width;
	private double height;
	private JTextField jlClock;
	//Boto de reiniciar la partida
	private JButton jbRestart;
	//Zona on hi han d'apareixer les puntuacions i els diferents botons de control per al jugador.
	private JPanel jpInfoPartida;
	//Zona de text sobre la puntuaci�
	private JTextField jlPuntuacio;
	private JTextField jlPuntsCPU;
	//private JPanel jpPuntsCPU;
	private String gameModes;
	//Array de paths per cercar les imatges a la carpeta del projecte
	static String files[] = {"Fitxa0.png", "Fitxa1.png",
		"Fitxa2.png", "Fitxa3.png",
		"Fitxa4.png", "Fitxa5.png",
		"Fitxa6.png","Fitxa7.png",
		"Fitxa8.png","Fitxa9.png",
		"Fitxa10.png","Fitxa11.png",
		"Fitxa12.png","Fitxa13.png",
		"Fitxa14.png","Fitxa15.png",
		"Fitxa16.png","Fitxa17.png","Fitxa18.png"};

	/**
	 * Constructor
	 * @param dificulty
	 * @param gameModes Tipus de partida
	 */

	public Scene(int dificulty, String gameModes){
		this.gameModes = gameModes;
		//size of the screen
		Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
		width = screenSize.getWidth();
		height = screenSize.getHeight();
		//Peticions de memoria
		inicialitzations(dificulty);
		
		this.deck = new Deck(numCartes);
		jlSuperior = new JLabel();
	
		//Panell lateral amb informaci� de la partida
		drawInfoPanel();
		
		//ADDs a JLSUPERIOR:
		jpInfoPartida.add(jbRestart);
		jpInfoPartida.add(Box.createRigidArea(new Dimension(5,100)));
		jpInfoPartida.add(jlPuntuacio);
		jpInfoPartida.add(jlPuntsCPU);
		if (gameModes != "Cpu"){
			jpInfoPartida.add(jlClock);
		}
		add(jlSuperior);
		//Col�loquem la imatge de fons
		jlSuperior.setIcon(new ImageIcon(drawBackground()));
		jbRestart.setLocation(780, 30);
		
		jlSuperior.add(jpInfoPartida);
		
		
		//posX i posY son variables auxiliars que modifiquem per pintar les cartes en punts x,y diferents a cada iteraci� del for
		createDeckMatrix(nImageGridPosX,nImageGridPosY);	
		//Modifiquem la mida de la finestra		
		setSize(1024,800);
	
		//Posici� de la finestra a la pantalla
		
	}
	
	
	/**
	 * Actualitza el temps de la partida a la label de jlClock
	 * @param temps String que indica el temps que �s.
	 */

	public void updateClock(String temps){
		jlClock.setText(temps);
	}
	
	/**
	 * Actualitza la puntuacio de la partida a la label de jlPuntuacio
	 * @param points Numero de punts
	 */

	public void updateScore(int points){
		jlPuntuacio.setText(points+" points");
	}
	
	/**
	 * Actualitza ounts de la CPU.
	 * @param points
	 */
	public void updateScoreCPU(int points){
		jlPuntsCPU.setText("");
		jlPuntsCPU.setText(points + " points");
	}

	
	/**
	 * Crea una matriu de cartes a partir de la deck de cartes i les afegeix al jlSuperior
	 * @param posX Posicio X inicial de la matriu
	 * @param posY Posicio Y inicial de la matriu
	 */

	public void createDeckMatrix(int posX,int posY){
		for(int i = 0 ; i < numCartes ; i++){
			if(i == saltDeFila1 || i == saltDeFila2  || i == saltDeFila3){
				posX= nImageGridPosX;
				posY=posY+espaiEntreCartes;
			}
			Card carta = deck.getList().get(i);
			deck.getList().remove(i);
			deck.getList().add(i, createCard (posX,posY,nImageScaleX ,nImageScaleY,files[18],i,carta));
			//Afegim la imatge al panell del fons i li assignem la capa numero 1 per superposar-la a la capa del fons
			jlSuperior.add(deck.getList().get(i));
			posX=posX+espaiEntreCartes;
		}
		
		
	}
	
	/**
	 * Crea una carta i la col�loca en la sev acorresponent posicio
	 * @param posX Posicio X de la carta
	 * @param posY Posicio Y de la carta
	 * @param scaleX Amplada de la carta
	 * @param scaleY Altura de la carta
	 * @param path Nom de la carta dins de files[]
	 * @param index Numero de carta dins la llista
	 * @param carta Parametre a omplir.
	 * @return Tipus carta amb totes aquestes caracteristiques.
	 */

	public Card createCard(int posX,int posY,int scaleX, int scaleY,String path,int index, Card carta){
		carta.setIcon(new ImageIcon(drawCard(path)));
		tapa(carta);
		carta.setBounds(posX, posY, scaleX, scaleY);
		carta.setBackground(Color.LIGHT_GRAY);
		return carta;
	}
	
	/**
	 * Selecciona una imatge de la carpeta per a que la poguem visualitzar al nostre joc
	 * @param path Indica quina imatge es vol buscar
	 * @return Un tipus de imatge que es visualitza en la pantalla del joc
	 */

	public BufferedImage drawCard(String path){
		ImageIcon icon = new ImageIcon("images/"+path);
		Image img = icon.getImage();
		BufferedImage bo = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_4BYTE_ABGR);
		Graphics g = bo.createGraphics();
		g.drawImage(img, -15, 378, 180, 260, null);
		return bo;
	}
	
	/**
	 * Crea al panell de la dreta del joc on s'hi mostra la informacio del temps i puntuacions, tot s'engloba en el JPanel jpInfoPartida
	 */

	public void drawInfoPanel(){
		//Crea panell d'info:
		
		if(!gameModes.equals("Cpu")){
			//si �s Countdown... 
			jlClock = new JTextField("");
			jlClock.setBackground(Color.WHITE);
			jlClock.setBorder(BorderFactory.createTitledBorder("Clock"));
			jlClock.setPreferredSize(new Dimension(250,100));
			
			
		}else{
			//si �s CPU...
			jlPuntsCPU = new JTextField("0 points");
			jlPuntsCPU.setEditable(false);
			jlPuntsCPU.setBackground(Color.WHITE);
			jlPuntsCPU.setPreferredSize(new Dimension(250,100));
			jlPuntsCPU.setBorder(BorderFactory.createTitledBorder("Puntuaci� CPU"));
			
			
		}
		jlPuntuacio = new JTextField("0 points");
		jlPuntuacio.setEditable(false);
		jlPuntuacio.setBackground(Color.WHITE);
	
		jlPuntuacio.setPreferredSize(new Dimension(250,100));
		
		jlPuntuacio.setBorder(BorderFactory.createTitledBorder("Puntuaci� Jugador"));
		
		
		jlPuntsCPU = new JTextField("0 points");
		jlPuntsCPU.setEditable(false);
		jlPuntsCPU.setBackground(Color.WHITE);
		jlPuntsCPU.setPreferredSize(new Dimension(250,100));
		jlPuntsCPU.setBorder(BorderFactory.createTitledBorder("Puntuaci� CPU"));
		
		jbRestart = new JButton("Go To Menu");
		jbRestart.setLocation(0, 0);
		
		jpInfoPartida = new JPanel();
		
		jbRestart.setPreferredSize(new Dimension(240,22));
		jpInfoPartida.setBorder(BorderFactory.createTitledBorder("Memory Game"));
		
		
		//POSICI� DE PANTALLA!!!!!!!
		jpInfoPartida.setBounds(1739, 0, 274, 752);
		jpInfoPartida.setBackground( new Color(0, 0, 0, 250) );
		jpInfoPartida.setOpaque(true);
	}
	
	
	/**
	 * Incialitza la posicio i el numero de cartes en fincio de la dificultat triada (difficulty)
	 * @param difficulty Nombre que ens indica en quina dificultat esta la partida 
	 */

	public void inicialitzations(int difficulty){
		switch(difficulty){
		case 1:
			nImageScaleX = 150;
			nImageScaleY = 150;
			//POSICI� DE PANTALLA!!!!!!!
			nImageGridPosX = 1050;
			nImageGridPosY = 180;
			numCartes = 6;
			saltDeFila1 = 3;
			saltDeFila2 = 8;
			saltDeFila3= 12;
			espaiEntreCartes = 180;
			break;
		case 2:
			nImageScaleX = 150;
			nImageScaleY = 150;
			//POSICI� DE PANTALLA!!!!!!!
			nImageGridPosX = 1030;
			nImageGridPosY = 120;
			numCartes = 12;
			saltDeFila1 = 4;
			saltDeFila2 = 8;
			saltDeFila3 = 12;
			espaiEntreCartes = 180;
			break;
		case 3: 
			nImageScaleX = 150;
			nImageScaleY = 150;
			//POSICI� DE PANTALLA!!!!!!!
			nImageGridPosX = 1020;
			nImageGridPosY = 30;
			numCartes = 16;
			saltDeFila1 = 4;
			saltDeFila2 = 8;
			saltDeFila3 = 12;
			espaiEntreCartes = 180;
			break;
		}
	}
	
	/**
	 * Selecciona la imatge de fons del joc de la carpeta per a que la poguem visualitzar al nostre joc 
	 * @return Un tipus de imatge que es pot visulatitzar en la partida
	 */

	public BufferedImage drawBackground(){
		ImageIcon icon = new ImageIcon("images/Background4.jpg");
		Image img = icon.getImage();
		BufferedImage bi = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_INT_ARGB);
		Graphics g = bi.createGraphics();
		
		//POSICI� DE PANTALLA!!!!!!!
		g.drawImage(img, 989, -100, 1024, 1000, null);
		return bi;
	}
	
	
	/**
	 * Crea una JLabel on es mostra el missatge de "YOU WIN" si el jugador ha guanyat
	 */

	public void winMessage(){
		JLabel winMessage = new JLabel("YOU WIN");
		winMessage.setBounds(0, 0, 100, 100);
		winMessage.setBackground(Color.YELLOW);
		jlSuperior.add(winMessage);
	}
	
	/**
	 * Destapa la carta corresponent als parametres que se li pasen
	 * @param index Identificador de la carta
	 * @param name Nom de la carta
	 */

	public void destapa(int index, int name) {
		ImageIcon icon = new ImageIcon("images/Fitxa"+index+".png");
		Image img = icon.getImage();
		BufferedImage bo = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_4BYTE_ABGR);
		Graphics g = bo.createGraphics();
		g.drawImage(img, -15, 378, 180, 260, null);
		deck.getList().get(name).setIcon( new ImageIcon(bo));
	}
	
	public Deck getDeck() {
		return deck;
	}
	
	public void setDeck(Deck deck) {
		this.deck = deck;
	}
	
	/**
	 * Destapa totes els cartes
	 */

	public void showInitalCards() {
		for(int i=0; i<deck.getList().size();i++){
			destapa(deck.getList().get(i).getID(),Integer.parseInt(deck.getList().get(i).getName()));	
		}
	}
	
	/**
	 * Posa boca avall totes les cartes
	 */

	public void hideInitialCards(){
		for(int i=0; i<deck.getList().size();i++){
			deck.getList().get(i).tapa();	
		}
	}
	
	
	/**
	 * Selecciona la imatge que tene totes les cartes al darrere i fa que sigui d'un tipus que es pugui veure en el joc
	 * @param carta Carta a la que col�loca la tapa darrere
	 * @return Un tipus carta amb tapa
	 */

	public Card tapa(Card carta) {
		ImageIcon icon = new ImageIcon("images/Fitxa18.png");
		Image img = icon.getImage();
		BufferedImage bo = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_4BYTE_ABGR);
		Graphics g = bo.createGraphics();
		g.drawImage(img, -15, 378, 180, 260, null);
		carta.setIcon( new ImageIcon(bo));
		return carta;
	}
	//----------------------------------------//
	//Controlador del Mouse Listener
	
	/**
	 * Afegeix controlador Mouse Listener als elements corresponents.
	 * @param controller Controlador del Mouse Listener
	 */

	public void establishController(newMouseListener controller) {
		//Afegim a les fitxes la capacitat de captar esdeveniments
		for(int i = 0 ; i < numCartes ; i++ ){
			(deck.getList().get(i)).addMouseListener(controller);
		}
		
		jbRestart.addActionListener(controller);
		jbRestart.setActionCommand("Back");
	}
}
