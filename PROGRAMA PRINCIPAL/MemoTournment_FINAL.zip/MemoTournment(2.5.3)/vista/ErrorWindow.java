package vista;

import javax.swing.JOptionPane;

/**
 * Vista per a mostrar un error quan es necesari.
 *
 */

public class ErrorWindow extends JOptionPane {
	private String message;
	
	/**
	 * Aquest constructor rep el missatge que es vol mostrar i l'iguala a la variable local
	 * @param message El missatge que vols mostrar a la finestra
	 */

	public ErrorWindow(String message){
		this.message = message;
	}
	
	/**
	 * Mostra el missatge que li han passat al constructor.
	 */

	public void show(){
		JOptionPane.showMessageDialog(null, message);
	}
}
