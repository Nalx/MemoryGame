package vista;

import java.awt.CardLayout;

import javax.naming.InitialContext;
import javax.swing.JFrame;
import javax.swing.JPanel;


/**
 * Classe que conte totes les Layout de totes les vistes que apareixen a la aplicaci�. 
 * Es la classe contenidora on es troben totes les vistes. Les operacions que conte 
 * serveixen per mostrar determinades vistes per pantalla, tamb� conte operacions per 
 * agregar vistes a la vista principal. 
 */

public class MainWindow extends JFrame {

	private JPanel cards;
	private CardLayout cardLayout;
	
	
	public MainWindow () {
		
		
		cardLayout = new CardLayout();
		//Fixem el layout
		getContentPane().setLayout(cardLayout);
		
		
		//Configuracio general de la finestra
		//setLocationRelativeTo(null);
		setLocation(150,0);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setSize(1024,800);

		
	}
	
	/**
	 * Agrega al panell principal de les vistes la vista del menu inicial.
	 * @param vistaI Objecte de la classe vista que implementa la vista inicial del menu.
	 */

	public void addInitialMenu(InitialMenu vistaI){
		getContentPane().add(vistaI,"Initial Menu");
	}
	
	/**
	 * Agrega al panell principal de les vistes la vista dels modes de joc.
	 * @param vistaG Objecte de la classe vista que implementa la vista de modes de joc de l'aplicaci�.
	 */

	public void addGameModes(GameModes vistaG){
		getContentPane().add(vistaG,"Game Modes");
	}
	
	/**
	 * Agrega al panell principal de les vistes la vista del Registre del jugador.
	 * @param vistaR Objecte de la classe vista que implementa la vista de registre.
	 */

	public void addRegistreMenu(RegistreMenu vistaR){
		getContentPane().add(vistaR, "Registre Menu");
	}
	
	/**
	 * Agrega la vista Scene a la vista principal.
	 * @param vistaS Vista del tipus Scene.
	 */

	public void addScene(Scene vistaS){
		getContentPane().add(vistaS, "Scene");
	}
	
	/**
	 * Agrega la vista de escollir Rankings a la finestra principal de l'aplicaci�.
	 * @param crView Vista de escollir Rankings
	 */

	public void addChooseRanking(ChooseRanking crView){
		getContentPane().add(crView, "Choose Ranking");
	}
	
	/**
	 * Agrega la vista de Rankings a la finestra principal.
	 * @param rView Vista de Rankings
	 */

	public void addRanking(Ranking rView){
		getContentPane().add(rView, "Ranking");
	}
	
	/**
	 * Agrega la vista de dificultats a la finestra principal.
	 * @param d Vista de dificultats.
	 */

	public void addDifficulty(Difficulty d){
		getContentPane().add(d, "Difficulty");
	}
	
	/**
	 * Agrega la vista de Memory a la finestra principal.
	 * @param c Vista de Memory
	 */

	public void addMemoConc(MemoConc c){
		getContentPane().add(c, "Memo");
	}
	
	/**
	 * Agrega la vista de Rating a la finestra principal.
	 * @param c Vista de Rating.
	 */

	public void addRating(Raiting c){
		getContentPane().add(c, "Rating");
	}
	
	/**
	 * Mostra la vista de Rating per pantalla.
	 */

	public void showRating(){
		cardLayout.show(getContentPane(), "Rating");
	}
	
	/**
	 * Mostra la vista de Memory per pantalla
	 */

	public void showMemoConc(){
		cardLayout.show(getContentPane(), "Memo");
	}
	
	/**
	 * Mostra la vista de dificultats per pantalla
	 */

	public void showDifficulty(){
		cardLayout.show(getContentPane(), "Difficulty");
	}
	
	/**
	 * Mostra la vista de Ranking per pantalla
	 */

	public void showRanking(){
		cardLayout.show(getContentPane(), "Ranking");
	}
	
	/**
	 * Mostra la vista de escollir ranking per pantalla
	 */

	public void showChooseRanking(){
		cardLayout.show(getContentPane(), "Choose Ranking");
	}
	
	/**
	 * Mostra la vista de escollir el mode de joc per pantalla
	 */

	public void showGameModes(){
		cardLayout.show(getContentPane(), "Game Modes");
	}
	
	/**
	 * Mostra el menu inicial per pantalla
	 */

	public void showInitialMenu(){
		cardLayout.show(getContentPane(), "Initial Menu");
	}
	
	/**
	 * Mostra la vista del Registre per pantalla.
	 */

	public void showRegistreMenu(){
		cardLayout.show(getContentPane(), "Registre Menu");
	}
	
	/**
	 * Mostra la vista de Scene per pantalla.
	 */

	public void showScene(){
		cardLayout.show(getContentPane(), "Scene");
	}


}
