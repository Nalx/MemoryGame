package vista;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import controller.LoginController;



/**
 * �s la vista del men� principal del joc.
 * On el jugador pot entrar amb la seva conta (guardada pr�viament en una base de dades), registar-se o b� entrar com a convidat sense ahver de registrar-se
 * per a jugar.
 * Tamb� pot sortir del joc (Exit)
 */

public class InitialMenu extends JPanel {

	private JLabel jlNickName;
	private JTextField jtfNickName;

	private JLabel jlPassword;
	private JTextField jtfPassword;

	private JButton jbLogin;

	private JPanel jpUp;

	private JButton jbSign;
	private JButton jbGuestUser;
	private JButton jbExit;



private JLabel jlSign;
	
	
	private JLabel jlSuperior;



	public InitialMenu() {


		jlSuperior = new JLabel();
		
		
		(jlSuperior).setIcon(new ImageIcon(posaImatge("menuInicial.jpg")));
		jlSuperior.setBounds(0,0,4440,3048);
		
		
		
		


		this.setLayout(null);

		//setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));

		//Creem un JPanel (jpUp) on s'engloben el NickName, la Password i el bot� de Login:

		//Camp del NickName:
		jlNickName = new JLabel("NickName");
		jtfNickName = new JTextField();
		jlNickName.setBounds(387, 240, 250, 24);
		jtfNickName.setBounds(387, 260, 250, 24);
		
		this.add(jlNickName);
		this.add(jtfNickName);


		//Camp de la Password:
		jlPassword = new JLabel("Password");
		jtfPassword = new JTextField();
		jlPassword.setBounds(387, 295, 250, 24);
		jtfPassword.setBounds(387, 315, 250, 24);

		this.add(jtfPassword);
		this.add(jlPassword);
		
		jbLogin = new JButton("Login");
		jbLogin.setBounds(472, 365, 80, 40);
		this.add(jbLogin);
		
		jbSign = new JButton("Sign In");
		jbGuestUser = new JButton("Guest User");
		jbExit = new JButton("Exit");
		
		jbSign.setBounds(387, 445, 250, 60);
		

		this.add(jbSign);

		
		
		jbGuestUser.setBounds(387, 535, 250, 60);
		this.add(jbGuestUser);
		
		jbExit.setBounds(437, 625, 150, 40);
		this.add(jbExit);
		
		
		
		this.add(jlSuperior);
	}

	/**
	 * Per a poder posar la imatge de fons
	 * @param nomImatge rep el nom de la imatge a posa rper a poder buscar-la a la carpeta de images
	 * @return Un tipus de imatge que es pot mostrar a la vista
	 */

	public BufferedImage posaImatge(String nomImatge){
		ImageIcon icon = new ImageIcon ("images/" + nomImatge);
		Image img = icon.getImage();
		BufferedImage bo = new BufferedImage(img.getWidth(null), img.getHeight(null),BufferedImage.TYPE_4BYTE_ABGR);
		Graphics g = bo.createGraphics();
		g.drawImage(img, 0, 0, 1024, 800, null);
		return bo;
	}
	
	

	/**
	 * S'estableix el controlador per a tots els botons d'aquesta vista
	 * @param controller Per establir la relaci� vista - controlador
	 */
	public void establishController(LoginController controller) {
		jbLogin.addActionListener(controller);
		jbLogin.setActionCommand("Login");

		jbSign.addActionListener(controller);
		jbSign.setActionCommand("Sign In");

		jbGuestUser.addActionListener(controller);
		jbGuestUser.setActionCommand("Guest User");

		jbExit.addActionListener(controller);
		jbExit.setActionCommand("Exit");

	}

	

	
	/**
	 * Per a rebre el que s'ha escrit a la textField de NickName
	 * @return Un string amb el NickName
	 */

	public String getTypedName() {
		return jtfNickName.getText();
	}
	
	
	/**
	 * Per a rebre el que s'ha escrit a la textField de Password
	 * @return Un string amb la Password
	 */

	public String getTypedPassword() {
		return jtfPassword.getText();
	}









}
