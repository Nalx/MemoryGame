package vista;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controller.GameModesController;


/**
 * Vista per mostrar el sistema de punts.
 *
 */

public class Raiting extends JPanel {

	
	private JButton jbGoBack;
	private JLabel jlSuperior;
	
	
	
	/**
	 * Mostra la vista que informa de les diferents puntuacions,  nomes consta de un JLabel per la imatge de fons i un boto per a 
	 * tornar enrera que esta colocat a partir de coordenades
	 */

	public Raiting(){

		
		jlSuperior = new JLabel();
		
		
		(jlSuperior).setIcon(new ImageIcon(fons()));
		jlSuperior.setBounds(0,-45,4444,3012);
		jlSuperior.setOpaque(true);
		
		this.setLayout(null);
		
		jbGoBack = new JButton("Go Back");
		jbGoBack.setBounds(462, 710, 100,30);
		
		this.add(jbGoBack);
		add(jlSuperior);
		
	}
	
	/**
	 * Fixa el controlador amb el boto	
	 * @param controller es la classe que controla el boto
	 */

		public void establishController(GameModesController controller) {
			jbGoBack.addActionListener(controller);
			jbGoBack.setActionCommand("BackR");
		}
		
		
		/**
		 * 	Serveix per redimensionar la imatge del fons segons la finestra. Es crea un ImageIcon a partir del path de la imatge,
		 * i a partir d'aqui i de crear una image (img) es crea la BufferedImage que es la que redimensionara. Finalment gracies a
		 * Graphics (g) es pinta la imatge per pantalla amb les dimensions requerides.	
		 * @return retorna la BufferedImage
		 */

		public BufferedImage fons(){
			ImageIcon icon = new ImageIcon ("images/rating.jpg");
			Image img = icon.getImage();
			BufferedImage bo = new BufferedImage(img.getWidth(null), img.getHeight(null),BufferedImage.TYPE_4BYTE_ABGR);
			Graphics g = bo.createGraphics();
			g.drawImage(img, 0, 0, 1024, 800, null);
			return bo;
		}
	
}
