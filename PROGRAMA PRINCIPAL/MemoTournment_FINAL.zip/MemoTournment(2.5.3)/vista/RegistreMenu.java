package vista;

import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import controller.LoginController;


/**
 * Vista per a poder registrarse al sistema.
 *
 */
	
public class RegistreMenu extends JPanel {
	
	private JButton jbRegister;
	private JButton jbRestore;
	private JButton jbCancel;
	
	private JLabel jlName;
	private JTextField jtfName;
	
	private JLabel jlPassword;
	private JTextField jtfPassword;

	private JLabel jlSuperior;
	
	
	/**
	 * Crea la vista per a registrar usuaris. El metode es el mateix que per les demes clases, un JLabel per la imatge de fons
	 * i els botons colocats per coordenades. A mes a mes aqui hi ha els JTextField per posar el nom i la contrasenya i el JLabel
	 * per el titol d'aquests JTextFields, aquests dos tambe van colocats per coordenades.
	 */

	public RegistreMenu() {
		
	jlSuperior = new JLabel();
		
		
	this.setLayout(null);

		(jlSuperior).setIcon(new ImageIcon(fons()));
		jlSuperior.setBounds(0,0,4440,3040);
		jlSuperior.setVisible(true);
		
	
			 
			 jlName = new JLabel("Login:");
			 jlName.setBounds(387, 240, 250, 24);	
			 jtfName = new JTextField();
			 jtfName.setBounds(387, 260, 250, 24);
			 add(jtfName);
			 add(jlName);
			 
			
		
			 jtfPassword = new JTextField();
			 jlPassword = new JLabel("Password:");
			 jtfPassword.setBounds(387, 320, 250,24);
			 jlPassword.setBounds(387, 300, 250,24);
			 
			 add(jlPassword);
			 add(jtfPassword);
			 
			
			 
			 jbRegister = new JButton("Register");
			 jbRegister.setBounds(387, 380, 250, 100);
			 jbRegister.setVisible(true);
			 
			 jbRestore = new JButton ("Restore");
			 jbRestore.setBounds(422, 500, 180, 75);
			 jbRestore.setVisible(true);
			 
			 jbCancel = new JButton ("Cancel");
			 jbCancel.setBounds(422, 590, 180, 75);
			 jbCancel.setVisible(true);
			 
			 
			 add(jbRegister);
			 add(jbRestore);
			 add(jbCancel);
			 add(jlSuperior);
			 
	}
	
	
	/**
	 * 	Serveix per redimensionar la imatge del fons segons la finestra. Es crea un ImageIcon a partir del path de la imatge,
	 * i a partir d'aqui i de crear una image (img) es crea la BufferedImage que es la que redimensionara. Finalment gracies a
	 * Graphics (g) es pinta la imatge per pantalla amb les dimensions requerides.	
	 * @return retorna la BufferedImage
	 */

	public BufferedImage fons(){
		ImageIcon icon = new ImageIcon ("images/signinfons.jpg");
		Image img = icon.getImage();
		BufferedImage bo = new BufferedImage(img.getWidth(null), img.getHeight(null),BufferedImage.TYPE_4BYTE_ABGR);
		Graphics g = bo.createGraphics();
		g.drawImage(img, 0, 0, 1024, 800, null);
		return bo;
	}
	
	/**
	 * Fixa els controladors amb els botons	
	 * @param controller Clase que controla els botons
	 */

	public void establishController(LoginController controller){
		jbRegister.setActionCommand("Register");
		jbRegister.addActionListener(controller);
		
		jbRestore.setActionCommand("Restore");
		jbRestore.addActionListener(controller);
		
		jbCancel.setActionCommand("Cancel");
		jbCancel.addActionListener(controller);
		
	}
	
	public String getTypedPassword(){
		return jtfPassword.getText();
	}
	public String getTypedName(){
		return jtfName.getText();
	}
	
	public void setTypedPassword(String s){
		jtfPassword.setText(s);
	}
	
	public void setTypedName(String s){
		jtfName.setText(s);
	}
	

}
