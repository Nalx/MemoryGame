package vista;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controller.GameModesController;
import controller.LoginController;

/**
 * Vista de la pantalla per escollir quin ranking veure.
 *
 */

public class ChooseRanking extends JPanel{

	private JLabel jlSuperior;
	private JButton jbMemoria;
	private JButton jbConcentracio;
	private JButton jbContra;
	private JButton jbReturn;
	
	/**
	 * Crea la vista, no s'utilitza cap layout en particular, simplement es coloca per coordenades i despres s'afegeix. Son 4 botons
	 * i el JLabel per la imatge del fons.
	 */

	public ChooseRanking(){
		
		this.setLayout(null);
		
		jlSuperior = new JLabel();
		
		
		
		(jlSuperior).setIcon(new ImageIcon(fons()));
		jlSuperior.setBounds(0,0,4440,3048);
		
		jbMemoria = new JButton("Memory Mode");
		jbMemoria.setBounds(337, 210, 350, 100);
		this.add(jbMemoria);
		
		jbConcentracio = new JButton("Concentration Mode");
		jbConcentracio.setBounds(337, 340, 350, 100);
		this.add(jbConcentracio);
		
		jbContra = new JButton("V.S. CPU Mode");
		jbContra.setBounds(337, 470, 350, 100);
		this.add(jbContra);
		
		jbReturn = new JButton("Return to Menu");
		jbReturn.setBounds(377, 620, 270, 50);
		this.add(jbReturn);
		
		
		this.add(jlSuperior);
		
	}
	
	/**
	 * 	Serveix per redimensionar la imatge del fons segons la finestra. Es crea un ImageIcon a partir del path de la imatge,
	 * i a partir d'aqui i de crear una image (img) es crea la BufferedImage que es la que redimensionara. Finalment gracies a
	 * Graphics (g) es pinta la imatge per pantalla amb les dimensions requerides.	
	 * @return retorna la BufferedImage
	 */

	public BufferedImage fons(){
		ImageIcon icon = new ImageIcon ("images/ranking.jpg");
		Image img = icon.getImage();
		BufferedImage bo = new BufferedImage(img.getWidth(null), img.getHeight(null),BufferedImage.TYPE_4BYTE_ABGR);
		Graphics g = bo.createGraphics();
		g.drawImage(img, 0, 0, 1024, 800, null);
		return bo;
	}
	
	/**
	 * Estableix els diferents controladors a cada boto
	 * @param c La classe controladora
	 */

	public void setController(GameModesController c){
		jbConcentracio.setActionCommand("Conc");
		jbConcentracio.addActionListener(c);
		
		jbMemoria.setActionCommand("Memo");
		jbMemoria.addActionListener(c);
		
		jbContra.addActionListener(c);
		jbContra.setActionCommand("Contra");
		
		jbReturn.setActionCommand("Return");
		jbReturn.addActionListener(c);
	}
}

