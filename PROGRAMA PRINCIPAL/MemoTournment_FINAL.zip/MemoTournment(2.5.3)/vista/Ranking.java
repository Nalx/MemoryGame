package vista;


import java.awt.Color;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;
import java.util.LinkedList;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.table.TableColumn;

import model.User;
import controller.GameModesController;
import controller.LoginController;

/**
 * Classe encarregada de mostrar la informaci� per pantalla del ranking dels jugadors. Es una vista.
*/


public class Ranking extends JPanel{

	private JScrollPane jspUsers;
	private JTextArea jtsUsers;
	private JButton jbGoBack;
	
	
	private JLabel jlSuperior;
	
	private JPanel jpSuperior;
	
	
	private JTable jtTaula;

	
	private TableColumn columna1;
	private TableColumn columna2;
	
	
	/**
	 * Constructor de la classe Ranking, s'encarrega de mostrar per pantalla la vista amb
	 * els elements corresponents que mostra la informaci� de Raking. Inicialitza i 
	 * configura la vista.
	 */

	public Ranking(){

		
		jlSuperior = new JLabel();
		
		
		(jlSuperior).setIcon(new ImageIcon(fons()));
		jlSuperior.setBounds(0,0,4440,3048);
		
		this.setLayout(null);
		
		
		
		
		jtsUsers = new JTextArea();
		jspUsers = new JScrollPane(jtsUsers);
		jbGoBack = new JButton("Go Back");

		jtTaula = new  JTable(13,1);
		
		jspUsers.setBounds(312, 215, 400, 400);

		jtsUsers.setOpaque(true);
		jspUsers.setBounds(312, 190, 400, 450);
		jtsUsers.setEditable(false);
		
		jbGoBack.setBounds(462, 660, 100,40);
		jbGoBack.setBackground(Color.yellow);
		
		this.add(jspUsers);
		this.add(jbGoBack);
		
		
		this.add(jlSuperior);
		


	}
	


	/**
	 * S'estableix el controlador pasat per parametres a la vista de Ranking.
	 * @param controller Controlador de la vista de modes de joc que tambe estableix la vista de Ranking.
	 */

	public void establishController(GameModesController controller) {
		jbGoBack.addActionListener(controller);
		jbGoBack.setActionCommand("Back");
	}
	
	
	/**
	 * Agrega una imatg al fons de la vista.
	 * @return Retorna un objecte de la classe BufferedImage amb la imatge de fons seleccionada.
	 */

	public BufferedImage fons(){
		ImageIcon icon = new ImageIcon ("images/ranking.jpg");
		Image img = icon.getImage();
		BufferedImage bo = new BufferedImage(img.getWidth(null), img.getHeight(null),BufferedImage.TYPE_4BYTE_ABGR);
		Graphics g = bo.createGraphics();
		g.drawImage(img, 0, 0, 1024, 800, null);
		return bo;
	}
	
	/**
	 * Retorna el text escrit al textarea de la vista de ranking.
	 * @return Retorna una cadena amb la informaci� de la text area.
	 */

	public String getTextRanking(){
		return jtsUsers.getText();
	}
	
	/**
	 * Seteja una series de valors del ranking a la area de text de la vista dels usuaris
	 * @param list LinkkedList d'Usuaris, amb la informaci� de tots els usuaris.
	 */


	public void setTextRanking(LinkedList<User> list){
		String s = ""
;		for (int i = 0;i< list.size(); i++){
			s += i+1 + ". " +list.get(i).getName() + "	" + list.get(i).getScore() + "\n";
		}
		
		jtsUsers.setText(s);
	}
	
	
	
	
	
}
