package vista;


import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.image.BufferedImage;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controller.GameModesController;
import controller.LoginController;


/**
 * Vista on es pot triar el mode de joc, veure el ranking de puntuacions, la informacio sobre la puntuacio o tornar endarrere.
 */

public class GameModes extends JPanel{
	private JButton jbTrial;
	private JButton jbCPU;
	private JButton jbRanking;
	private JButton jbLogOut;
	private JButton jbInfo;
	
	
	private JLabel jlSuperior;
	
	public GameModes(){
		
		
		
		
		jlSuperior = new JLabel();
		
		
		(jlSuperior).setIcon(new ImageIcon(posaImatge("fons.jpg")));
		jlSuperior.setBounds(0,0,1600,1096);
		
		this.setLayout(null);
		
		jbTrial = new JButton("Countdown");
		jbTrial.setBounds(262, 75, 500, 100);
		add(jbTrial);

		jbCPU = new JButton("CPU");
		jbCPU.setBounds(262, 200, 500, 100);
		this.add(jbCPU);

		jbRanking = new JButton("Ranking");
		jbRanking.setBounds(262, 325, 500, 100);
		this.add(jbRanking);


		jbInfo = new JButton("Info");
		jbInfo.setBounds(262, 450, 500, 100);
		this.add(jbInfo);
		
		jbLogOut = new JButton("Logout");
		jbLogOut.setBounds(262, 575, 500, 100);
		this.add(jbLogOut);
		
		this.add(jlSuperior);
		
	}
	
	
	/**
	 * Per a poder posar la imatge de fons
	 * @param nomImatge rep el nom de la imatge a posa rper a poder buscar-la a la carpeta de images
	 * @return Un tipus de imatge que es pot mostrar en la vista
	 */

	public BufferedImage posaImatge(String nomImatge){
		ImageIcon icon = new ImageIcon ("images/" + nomImatge);
		Image img = icon.getImage();
		BufferedImage bo = new BufferedImage(img.getWidth(null), img.getHeight(null),BufferedImage.TYPE_4BYTE_ABGR);
		Graphics g = bo.createGraphics();
		g.drawImage(img, 0, 0, 1024, 800, null);
		return bo;
	}
	
	/**
	 * S'estableix el controlador per a tots els botons d'aquesta vista
	 * @param c Per establir la relaci� vista - controlador
	 */

	public void establishController(GameModesController c){
		jbTrial.setActionCommand("Trial");
		jbTrial.addActionListener(c);
		jbCPU.setActionCommand("Cpu");
		jbCPU.addActionListener(c);
		jbRanking.setActionCommand("Ranking");
		jbRanking.addActionListener(c);
		jbLogOut.setActionCommand("Logout");
		jbLogOut.addActionListener(c);
		jbInfo.addActionListener(c);
		jbInfo.setActionCommand("Info");
	}

	
	
}
	
	
