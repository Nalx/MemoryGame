package vista;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controller.GameModesController;


/**
 * Vista on el jugador pot triar , dins del mode Contrarrellotge, si jugar al mode Memory (Memory Mode) o al mode concentraci� (Concentration Mode).
 * La diferencia est� en que al mode concentraci� al principi de la partida es mostren les cartes un instant, despr�s es giren i comenca la partida 
 */

public class MemoConc extends JPanel {
	
	private JButton jbMemo;
	private JButton jbConc;
	private JButton jbReturn;

	
	private JLabel jlSuperior;
	
	
	public MemoConc(){
		
		this.setLayout(null);
		
		
		jlSuperior = new JLabel();
		
		
		(jlSuperior).setIcon(new ImageIcon(posaImatge("fons.jpg")));
		jlSuperior.setBounds(0,0,1600,1096);
		
		
		
		jbMemo = new JButton("Memory Mode");
		jbMemo.setBounds(262, 225, 500, 100);
		
		jbConc = new JButton("Concentration Mode");
		jbConc.setBounds(262, 375, 500, 100);
		
		jbReturn = new JButton("Return to Menu");
		jbReturn.setBounds(377, 620, 270, 50);
		
		
		
		this.add(jbReturn);
		this.add(jbMemo);
		this.add(jbConc);
		this.add(jlSuperior);
		
	}
	
	/**
	 * S'estableix el controlador per a tots els botons d'aquesta vista
	 * @param c Per establir la relaci� vista - controlador
	 */

	public void setController(GameModesController c){
		jbMemo.setActionCommand("Memory");
		jbMemo.addActionListener(c);
		
		jbConc.setActionCommand("Concentration");
		jbConc.addActionListener(c);
		
		jbReturn.setActionCommand("Return");
		jbReturn.addActionListener(c);	
	
		
	}
	
	/**
	 * Per a poder posar la imatge de fons
	 * @param nomImatge rep el nom de la imatge a posa rper a poder buscar-la a la carpeta de images
	 * @return Un tipus de imatge que es pot veure en la la nostre vista
	 */

	public BufferedImage posaImatge(String nomImatge){
		ImageIcon icon = new ImageIcon ("images/" + nomImatge);
		Image img = icon.getImage();
		BufferedImage bo = new BufferedImage(img.getWidth(null), img.getHeight(null),BufferedImage.TYPE_4BYTE_ABGR);
		Graphics g = bo.createGraphics();
		g.drawImage(img, 0, 0, 1024, 800, null);
		return bo;
	}
}
