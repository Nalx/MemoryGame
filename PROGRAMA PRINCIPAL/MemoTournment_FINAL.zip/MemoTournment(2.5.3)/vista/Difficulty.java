package vista;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controller.GameModesController;


/**
 * Classe que mostra per pantalla la pantalla de dificultats del joc del memory.
 */

public class Difficulty extends JPanel {
	
	private JButton jbEasy;
	private JButton jbNormal;
	private JButton jbHard;
	private JButton jbReturn;
	
	private JLabel jlSuperior;
	
	/**
	 * Constructor de la classe Dificulty que incialitza i seteja de mode correcte els elements de 
	 * la vista.
	 */
	public Difficulty(){
		
		this.setLayout(null);
		
		
		jlSuperior = new JLabel();
		
		
		(jlSuperior).setIcon(new ImageIcon(posaImatge("fons.jpg")));
		jlSuperior.setBounds(0,0,1600,1096);
		
		
		
		jbEasy = new JButton("Easy");
		jbEasy.setBounds(262, 150, 500, 100);
		
		jbNormal = new JButton("Normal");
		jbNormal.setBounds(262, 300, 500, 100);
		
		
		jbHard = new JButton("Hard");
		jbHard.setBounds(262, 450, 500, 100);
		
		jbReturn = new JButton("Return to Menu");
		jbReturn.setBounds(377, 620, 270, 50);
		
		this.add(jbReturn);
		this.add(jbEasy);
		this.add(jbNormal);
		this.add(jbHard);
		this.add(jlSuperior);
		
	}
	
	/**
	 * Classe que linkeja esl controladors pertinents als elements interactius de la vista de dificultats.
	 * @param c Controlador al qual s'assignaran els elements de la vista.
	 */

	public void setController(GameModesController c){
		jbEasy.setActionCommand("Easy");
		jbEasy.addActionListener(c);
		
		jbNormal.setActionCommand("Normal");
		jbNormal.addActionListener(c);
		
		jbHard.setActionCommand("Hard");
		jbHard.addActionListener(c);
		
		jbReturn.setActionCommand("Return");
		jbReturn.addActionListener(c);	
	}
	
	/**
	 * Classe que permet posar com a fons de pantalla de la vista de dificultats la imatge que es desitgi.
	 * @param nomImatge Nom del arxiu de la imatge que es mostrara com a fons de la vista.
	 * @return Retorna un objecte de la classe BufferedImage amb el valor de la imatge passada per pantalla creada.
	 */

	public BufferedImage posaImatge(String nomImatge){
		ImageIcon icon = new ImageIcon ("images/" + nomImatge);
		Image img = icon.getImage();
		BufferedImage bo = new BufferedImage(img.getWidth(null), img.getHeight(null),BufferedImage.TYPE_4BYTE_ABGR);
		Graphics g = bo.createGraphics();
		g.drawImage(img, 0, 0, 1024, 800, null);
		return bo;
	}
}
