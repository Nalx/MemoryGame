package model;


/**
 * Classe encarregada de gestionar el comportament del joc, aquesta classe implementa com 
 * es juga al joc i gestiona el comportament de les cartes.  Amb aquesta classe tamb� es 
 * gestionen comportaments de les cartes, com posar parelles, inicialitzar cartes quan 
 * comen�a un mode de joc, etc. 
*/

public class Logica {
	
	//Comptador d'encerts
	private int correctCards;
	//Alternador de clicks 1,2,1,2...
	private int numClicksParella;
	private Card[] cardPair;
	//correctCards �s el nombre d'encerts que s'ha d'assolir per guanyar
	private int numCartes;
	private int nPunts;
	private int nIncrement;

	public Logica(int difficulty){
		inicialitzations(difficulty);
		this.cardPair = new Card[2];
		this.correctCards = 0;
		this.numClicksParella = 0;
		nPunts=0;
	}
	
	/**
	 * 
	 * Metode que retorna Id de la carta en la posicio 0 de l'array de cartes.
	 * @return Retorna un enter amb el nombre de la ID.
	 */

	public int getCardID(){
		return cardPair[0].getID();
	}
	
	/**
	 * Incrementa el nombre de cartes correctes
	 */

	public void IncrementCorrectCards(){
		correctCards ++;
	}

	/**
	 * Agrega una carta y la compara amb altres cartes. Si aquestes dos s�n parella incrementa el nombre de punts. 
	 * @param card Objecte del tipus carta que sera amb el que es comparara i agregara.
	 * @return Retorna una cadena de caracters amb el resultat de la agregacio de la carta.
	 */

	public String addCard(Card card){
		if(numClicksParella == 0){
			cardPair[0] = card;
			numClicksParella++;
		}
		if(numClicksParella == 1 && 
				!(cardPair[0].getName().equals(card.getName()) && cardPair[0].getID() == card.getID()) ){
			cardPair[1]= card;
			numClicksParella = 0;

			if(compareCards()){
				
				nPunts=nPunts+nIncrement;
				return "Correct";
				
			}
			return "Wrong";
		}
		return "Same";
	}

	
	/**
	 * Retorna el nombre de punts del jugador
	 * @return Retorna un enter amb el nombre de punts
	 */

	public int getnPunts() {
		return nPunts;
	}

	/**
	 * Seteja el atribut de punts al parametre enviat
	 * @param nPunts Enter amb el nombre de punts a copiara l'atribut de punts.
	 */

	public void setnPunts(int nPunts) {
		this.nPunts = nPunts;
	}
	
	/**
	 * Retorna l'array de cartes del joc.
	 * @return Retorna l'array de cartes del joc.
	 */

	public Card[] getCardPair() {
		return cardPair;
	}
	
	/**
	 * Seteja l'array de cartes amb l'array de cartes que es pasa per parametres.
	 * @param cardPair Array de cartes que escopiara a l'atribut.
	 */

	public void setCardPair(Card[] cardPair) {
		this.cardPair = cardPair;
	}
	
	/**
	 * Aquesta classe indica quan s'ha finalitat, el joc, ja s'han trobat totes les parelles.
	 * @return Retorna un bollea depenent si s'ha finalitzat el joc (trobat totes les parelles)
	 */

	public boolean finished(){
		if (correctCards == numCartes){
			return true;
		}
		return false;
	}
	
	/**
	 * Compara si dos cartes de l'array de cartes s�n iguals (so parella) y retorna un boolea si ho s�n o no. 
	 * @return Retorna un boolea depenent de si s�n parella o no.
	 */

	public boolean compareCards ( ){
		if (cardPair[0].getID() == cardPair[1].getID() && !cardPair[0].getName().equals(cardPair[1].getName())){
			correctCards++;
			return true;
		}
		return false;
	}
	
	/** 
	 * Chequeja si ja s'han colocat totes les parelles al joc. 
	 * @return Retorna un boolea en el que el valor dependra de si ja es troben totes les parellesen joc.
	 */

	public boolean checkEnd(){
		if (correctCards == (numCartes/2)){
			return true;
		}
		return false;
	}
	
	/**
	 * Aquesta classe steja els parametres del mode de joc depenent de la dificultat que es passi per parametres.
	 * @param difficulty Dificultat amb la qual el jugador jugar�.
	 */

	public void inicialitzations(int difficulty){
		switch(difficulty){
		case 1:
			numCartes = 3;
			nIncrement = 100;
			break;
		case 2:
			numCartes = 6;
			nIncrement = 200;
			break;
		case 3: 
			numCartes = 8;
			nIncrement = 300;
			break;
		}
	}
}
