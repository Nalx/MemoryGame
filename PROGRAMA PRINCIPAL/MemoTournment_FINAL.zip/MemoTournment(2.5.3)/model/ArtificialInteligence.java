package model;


/**
 * Clase encarregada de gestionar el comportament de la intel�lig�ncia artificial (IA o CPU) que controla el joc del memory quan es 
 * juga contra la maquina. Els m�todes que implemeta son comportaments de la IA, com escollir una carta aleat�ria, guardar les
 *  combinacions que realitza la maquina o guardar la puntuaci� de la maquina.
 */

public class ArtificialInteligence {
	private int randLim;
	private Card cardpair [];
	private int userScore;
	private int machineScore;
	private Deck aux;
	private Deck deckAux;
	private int dificultat;
	
	/**
	 * Clase que controla la inteligencia artificial i tot lo relacionat amb la CPU
	 * @param difficulty Nivell de dificultat que tindra la CPU (regula el % de acertar carta)
	 * @param deck Pasa el conjunt de cartes per a poderles manipular.
	 */

	public ArtificialInteligence(int difficulty, Deck deck) {
		
		init(difficulty);
		this.dificultat = difficulty;
		this.deckAux = deck;
		System.out.println("Dificultat="+difficulty);
		cardpair = new Card [2];
		userScore = 0;
		machineScore = 0;
		aux = new Deck(deck.getList().size());
		//Capia exacte de la deck 
		for (int i = 0; i < deck.getList().size(); i++){
			aux.getList().remove(i);
			aux.getList().add(i, deck.getList().get(i));
		}
		System.out.println("----------------------------------------");
		System.out.println("Deck Principal:");
		for(int i = 0 ; i < deck.getList().size() ; i++){
			System.out.println("ID:"+deck.getList().get(i).getID()+" Name:"+deck.getList().get(i).getName());
		}
		System.out.println("----------------------------------------");
		System.out.println("Deck AUX:");
		for(int i = 0 ; i < aux.getList().size() ; i++){
			System.out.println("ID:"+aux.getList().get(i).getID()+" Name:"+aux.getList().get(i).getName());
		}
	}
	
	
	/**
	 * Elimina de la baralla de cartes les que ha encertat l'usuari a menys que hagi acabat la partida.
	 * @param id Id de la carta a borrar
	 */

	//Eliminem de la baralla de cartes les que ha encertat l'usuari
	public void setUserChosenCards(int id){
		int num=0;
		if(aux.getList().size()==0){
			System.out.println("End Game");
		}else{
			for (int i = 0; i < aux.getList().size(); i++){
				if (aux.getList().get(i).getID() == id){
					aux.getList().remove(i);
					num++;
				}	
			}
			System.out.println("Cartes restants:");
			for (int i = 0; i < aux.getList().size(); i++){
				System.out.println("ID:"+aux.getList().get(i).getID()+"Name:"+aux.getList().get(i).getName());
			}
		}
	}
	
	/**
	 * Esborrem de la baralla de cartes la que ha encertat la CPU
	 * @param id Id de la carta a borrar
	 */

	//Eliminem de la baralla de cartes les que ha encertat la CPU
	public void setCPUChosenCards(int id){
		int num=0;
		System.out.println("ID CARD="+id);
		for (int i = 0; i < aux.getList().size(); i++){
			if (aux.getList().get(i).getID() == id){
				aux.getList().remove(i);
				System.out.println("CPUCardsEliminated"+num+":   ID:"+aux.getList().get(i).getID()+" Name:"+aux.getList().get(i).getName());
				num++;
			}	
		}
		System.out.println("Cartes restants:");
		for (int i = 0; i < aux.getList().size(); i++){
			System.out.println("ID:"+aux.getList().get(i).getID()+"Name:"+aux.getList().get(i).getName());
		}
	}
	
	public void IncrementUserScore(){
		userScore++;
	}
	
	private void IncrementMachineScore(){
		machineScore++;
	}
	
	/**
	 * Li pases el array de cartes i comprova si no hi ha cartes(false) o si son iguals(true) o si son diferents(false).
	 * @param array el array de cartes a comparar
	 * @return retorna true o false segons si son iguals(true) o si son diferents o no hi ha cartes(false)
	 */

	public boolean compareCards (Card array[]){
		if(array[0]== null || array[1]== null){
			System.out.println("No hi ha cartes");
			
		}else{
		if (array[0].getID() == array[1].getID()){
			return true;
		}
		}
			return false;
	
	}
	
	/**
	 * Inicialitza els limits del azar segons la dificultat.
	 * @param d la dificultat escollida.
	 */

	public void init(int d){
		switch(d){
		case 1:
			randLim = 3;
			break;
		case 2:
			randLim = 5;
			break;
		case 3:
			randLim = 7;
			break;			
		}
	}
	
	/**
	 * Calcula si acerta o no segons si el numero esta per sota del limit fixat al init
	 * @return retorna true o fals segons li toca acertar(true) o fallar (false)
	 */

	private boolean goodOrbad(){
		
		int r = (int) (Math.random()*10+1);
		
		if (r <= randLim){
			return true;
		}
		return false;
	}
	
	/**
	 * Escolleix una carta aleatoria a partir d'un int i el size de la deck.
	 * @return retorna un int amb el numero de la carta escollida
	 */

	private int chooseRandomCard(){
		int r=0;
		System.out.println("Dificultat"+dificultat);
		switch(dificultat){
		case 1: 
			r = (int) (Math.floor(Math.random() * aux.getList().size()));
		break;
		case 2: 
			r = (int) (Math.random()*aux.getList().size());
		break;
		case 3: 
			r = (int) (Math.random()*aux.getList().size());
		break;
		}
		
		return r;
	}
	
	
	/**
	 * Tot el procediment per escollir les cartes apropiades, s'agafen dos que coincideixin i dos que no, i segons si ha d'acertar o no
	 * ens quedem amb unes o amb altres.
	 * @return retorna un array amb les dos cartes escollides.
	 * */

	public Card[] chooseCard(){	
		int randomCard = chooseRandomCard();
		System.out.println("Carta1Escollida="+ randomCard);
		System.out.println("----------------------------------------");
		System.out.println("Deck CPU:");
		for (int i = 0; i < aux.getList().size(); i++){
			System.out.println("ID: "+aux.getList().get(i).getID()+" Name: "+aux.getList().get(i).getName());
		}
		
		Card array [] = new Card[2];
		
		
		//Esborrem la que hem escollit primer????
		
		//Si a la baralla nom�s hi ha 2 cartes
		if(aux.getList().size()==2){
			array[0] = aux.getList().get(0);
			array[1] = aux.getList().get(1);
			System.out.println("nomes 2 cartes");
		}else{
			Card c = aux.getList().get(randomCard );
			array[0] = c;
			aux.getList().remove(randomCard);
		//Ens guardem una combinaci� correcte de cartes
		if (goodOrbad()){
			
			System.out.println("Mida de la deck AUX= "+aux.getList().size());
			for (int i = 0; i < aux.getList().size(); i++){
				if (c.getID() == aux.getList().get(i).getID() && c.getName() != aux.getList().get(i).getName()){
					array[1] = aux.getList().get(i);
					aux.getList().remove(i);
					IncrementMachineScore();
					return array;
				}
			}
		//Ens guardem una combinaci� incorrecte de cartes	
		}else{
			for (int i = 0; i < aux.getList().size(); i++){
				if (c.getID() != aux.getList().get(i).getID()){
					array[1] = aux.getList().get(i);
					//SI ES INCORRECTE NO S'HA D'ELIMINAR sino AFEGIR la carta random inicial
					aux.getList().add(randomCard , array[0]);
					return array;
				}
			}			
		}
		System.out.println("Cartes restants:");
		for (int i = 0; i < aux.getList().size(); i++){
			System.out.println("EEEEEID:"+aux.getList().get(i).getID()+"Name:"+aux.getList().get(i).getName());
		}
		}
		return array;
	}

	public int getMachineScore() {
		return machineScore;
	}
	public void setMachineScore(int machineScore) {
		this.machineScore = machineScore;
	}
	public int getUserScore() {
		return userScore;
	}

	public void setUserScore(int userScore) {
		this.userScore = userScore;
	}
	public boolean endGame(){
		if(aux.getList().size() <= 2){
			return true;
		}
		return false;
	}
}
