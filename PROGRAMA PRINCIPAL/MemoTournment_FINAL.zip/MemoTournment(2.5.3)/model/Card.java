package model;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.image.BufferedImage;

import javax.swing.ImageIcon;
import javax.swing.JLabel;

/**
 * El nostre memory consta d'un nombre de cartes que disposen d'un nom i un identificador per a poder-les diferenciar.
 * @param ID Identificador de la carta (no n'hi ha dos d'iguals)
 * @param name Nom de la carta (si que es pot repetir)
 */


public class Card extends JLabel{
	private int ID;
	private String name;
	public Card(int ID, String name){
		this.ID = ID;
		this.name = name;

	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		ID = iD;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	
	
	/**
	 * Col�loca la imatge del darrere de les cartes (Fitxa18.png)
	 */
	public void tapa(){
		ImageIcon icon = new ImageIcon("images/Fitxa18.png");
		Image img = icon.getImage();
		BufferedImage bo = new BufferedImage(img.getWidth(null), img.getHeight(null), BufferedImage.TYPE_4BYTE_ABGR);
		Graphics g = bo.createGraphics();
		g.drawImage(img, -15, 378, 180, 260, null);
		this.setIcon( new ImageIcon(bo));
	}
}
