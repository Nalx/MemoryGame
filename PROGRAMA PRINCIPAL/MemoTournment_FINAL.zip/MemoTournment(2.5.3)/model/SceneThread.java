package model;

import vista.Scene;

/**
 * Thread on s'inicia la partida
 *
 */
public class SceneThread implements Runnable{
	private Scene vista;
	private long sleepTime = 1000;
	private Deck llista;
	private Countdown countdown;


	/**
	 * Constructor.
	 * @param llista Tota la llista de cartes del joc
	 * @param vista Vista de la partida, on s'hi veuen les cartes, el punts, el comptador, etc.
	 */

	public SceneThread(Deck llista,Scene vista, long sleepTime){
		this.llista = llista;
		this.vista = vista;
		this.sleepTime = sleepTime;
		
		
	}
	
	/**
	 * Implementa el thread, inicia les cartes inicials.
	 */

	public void run() {
		try {
			Thread.sleep(sleepTime);
		} catch (InterruptedException e) {
			System.out.println("Thread Error!");
		}
		vista.hideInitialCards();
	}

}
