package model;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;

/**
 * Classe per guardar i manipular la deck de cartes.
 *
 */

public class Deck {
	private LinkedList<Card> cardDeck;
	private int numCartes;
	private Card cardAux;

	/**
	 * S'inicialitza la deck segons el nombre total de cartes.
	 * @param numCartes nombre total de cartes
	 */

	public Deck(int numCartes){
		cardDeck = new LinkedList();
		this.numCartes = numCartes;
		for (int i = 0; i < numCartes; i++){
			cardDeck.add(new Card(0," "));
		}	
		idInitialization();
		shuffle();
	}

	/**
	 * Funcio per inicialitzar la deck, a partir de la meitat del deck les id tornen a comen�ar desde 0
	 */

	public void idInitialization(){
		for(int i = 0 ; i < numCartes ; i++){
			if(i>=(numCartes/2)){
				//Fem el mod a partir de la meitat de numCartes
				//En el cas que hi hagin 12 cartes:
				//carta 6-> ID=0,carta 7-> ID=1, carta 8-> ID=2...fins a la carta n
				cardDeck.get(i).setID(i%(numCartes/2));
			}else{
				// carta 0-> ID=0, carta 1-> ID=1,carta 2-> ID=2...fins a la carta 5
				cardDeck.get(i).setID(i);
			}
			cardDeck.get(i).setName(String.valueOf(i));
			
		}
	}
	
	/**
	 * funcio que serveix per barallar el conjunt de cartes, es posen les id en una linked list auxiliar i es barallen amb la funcio
	 * shuffle que incorpora la llibreria Collections. Despres d'aixo es tornen a pasar les id al deck de cartes
	 */

	public void shuffle(){
		LinkedList<Integer> auxlist = new LinkedList();
		//recuperar info a la linkedlist local
		for(int i = 0 ; i < numCartes ; i++){
			auxlist.add(cardDeck.get(i).getID());
		}
		//Volcatge a la linkedList general
		Collections.shuffle(auxlist, new Random());
		for(int i = 0 ; i < numCartes ; i++){
			cardDeck.get(i).setID(auxlist.get(i)); 
		}
		
	}
	public LinkedList<Card> getList(){
		return cardDeck;
	}
	public void setList(LinkedList<Card> cardDeck){
		this.cardDeck = cardDeck;
	}
}
