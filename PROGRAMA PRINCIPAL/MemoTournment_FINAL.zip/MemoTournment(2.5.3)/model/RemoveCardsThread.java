/*Thread per eliminar les cartes correctes 
 * al passar 1 segon despres de obrir-les.
 * 
 */



package model;

import java.applet.AudioClip;

import vista.Scene;


/**
 * 
 * Classe que implementa un Thread que s'encarrega de no fer visibles cartes si aquestes no s�n parella.
*/

public class RemoveCardsThread  implements Runnable  {
	// Temps que les cartes queden destapades
	private static final long sleepTime = 2000;

	private Scene vista;
	private Card[] cartes;
	private Deck llista;

	public RemoveCardsThread (Card[] cartes, Deck llista){
		this.cartes = cartes;
		this.llista = llista;
	}

	
	/**
	 * El metode que executa el Thread, s'encarrega de no fer visibles les cartes de la Deck de 
	 * cartes si aquestes no s�n parella.
	 */

	public void run() {
		try {
			Thread.sleep(sleepTime);
		} catch (InterruptedException e) {
			System.out.println("Thread Error!");
		}
		for(int i=0; i<llista.getList().size(); i++){
			if(cartes[0].getID() == llista.getList().get(i).getID()){
				llista.getList().get(i).setVisible(false);
			}
			if(cartes[1].getID() == llista.getList().get(i).getID()){
				llista.getList().get(i).setVisible(false);
				AudioClip sound;
				sound = java.applet.Applet.newAudioClip(getClass().getResource("/images/correct.wav") );
				sound.play();
			}

		}
	}




}