package model;

import javax.swing.Timer;

import controller.GameModesController;
import controller.newMouseListener;

/**
 * 
 * �s el comptador de la partida en contrarrellotge.
 *
 */

public class Countdown {
	
	private int initialTime;
	private Timer countDown;
	private int actualTime;
	private int timeCounter;
	private int score;
	private int increment;
	
	
	/**
	 * Constructor.
	 * @param difficulty S'ha de tenir en compte el nivell de dificultat de la partida a l'hora d'inicialitzar tots el camps d'aquesta
	 * @param nmController Gr�cies al Timer countDown, aquest rep un event cada 1000 milisegons
	 */
	public Countdown(int difficulty, newMouseListener nmController){
		
		countDown = new Timer(1000,nmController);
		initializations(difficulty);
		timeCounter= 0;
	}
	
	
	/**
	 * Retorna el temps actual
	 * @return String amb el temps actual en format minuts i segons
	 */

	public String updateActualTime(){
		int sec;
		int min;

		actualTime-=1;
		min = (actualTime)/60;
		sec = (actualTime)%60;
		timeCounter+=1000;
		if (sec/10 != 0){
			return ("0"+min+":"+sec);
		}
		else{
			return ("0"+min+":0"+sec);
		}
	}
	
	/**
	 * Comunica, amb boolenas, si el temps de joc s'ha acabat
	 * @return Un boole� que �s true si el temps s'ha acabat o false si encara no
	 */
	public boolean endTime(){
		if(timeCounter ==initialTime){
			return true;
		}
		return false;
	}
	
	/**
	 * Inicia el comptador. 
	 */
	public void timeStart(){
		countDown.start();
	}
	
	/**
	 * Para el comptador
	 */
	public void timeStop(){
		countDown.stop();
	}
	
	/**
	 * Inicialitza els temps inicial (initialTime) i l'increment dels punts (increment) segons la dificultat que rep en forma de nombre enter (difficulty)
	 * @param difficulty Nombre enter per a saber quina de les 3 dificultats hem d'usar
	 */

	public void initializations(int difficulty){
		switch(difficulty){
		
		case 1:
			initialTime = 120000;
			increment = 100;
			break;
		case 2:
			initialTime = 90000;
			increment = 200;
			break;
		case 3:
			initialTime = 60000;
			increment = 300;
			break;
		}
		
		
		actualTime = initialTime/1000;
		
	}
	
	
	/**
	 * Calcula la puntuacio tenint en compte el temps restant i la dificultat
	 * @return La puntuacio en forma d'enter
	 */
	public int getScore(){
		
		score = actualTime*increment;
		return score;
	}
}
