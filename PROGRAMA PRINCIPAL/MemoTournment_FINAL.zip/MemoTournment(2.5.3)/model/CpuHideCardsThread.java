package model;

import vista.Scene;

/*Thread per amagar les cartes incorrectes 
 * al passar 1 segon despres de obrir-les.
 * 
 */

/**
 * Thread per amagar les cartes incorrectes 
 * al passar 1 segon despres de obrir-les. 
 */

public class CpuHideCardsThread implements Runnable  {
	// Temps que les cartes queden destapades
	private static final long sleepTime = 5000;
	private Card carta;
	private Scene vista;
	private Deck llista;
	public CpuHideCardsThread(Card carta,Scene vista,Deck llista){
		this.carta = carta;
		this.vista = vista;
		this.llista = llista;
	}

	/**
	 * espera 5 segons i despres tapa la carta que li han pasat al constructor
	 */

	public void run() {
		try {
			Thread.sleep(sleepTime);
		} catch (InterruptedException e) {
			System.out.println("Thread Error!");
		}
		for(int i=0; i<llista.getList().size(); i++){
			if(carta.getID() == llista.getList().get(i).getID()){
				llista.getList().get(i).tapa();
			}
		
		}
	}

}

