package model;
/*Thread per amagar les cartes incorrectes 
 * al passar 1 segon despres de obrir-les.
 * 
 */
import vista.Scene;

/**
 * Thread per amagar les cartes incorrectes 
 * al passar 1 segon despres de obrir-les.
 * 
 */

public class CpuShowCardsThread implements Runnable  {
	// Temps que les cartes queden destapades
	private static final long sleepTime = 3000;
	private Scene vista;
	private Card carta;
	private Deck llista;

	public CpuShowCardsThread(Card carta, Scene vista,Deck llista){
		this.carta = carta;
		this.vista = vista;
		this.llista = llista;
	}

	/**
	 * espera 5 segons i despres ensenya la carta que li han pasat al constructor
	 */

	public void run() {
		try {
			Thread.sleep(sleepTime);
		} catch (InterruptedException e) {
			System.out.println("Thread Error!");
		}
		for(int i=0; i<llista.getList().size(); i++){
		if(Integer.parseInt(carta.getName()) == Integer.parseInt(llista.getList().get(i).getName())){
			vista.destapa(carta.getID(), Integer.parseInt(carta.getName()));
		}	
	}
}
}

