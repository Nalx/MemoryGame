package model;

import java.io.Serializable;

/**
 * Serveix per guardar els usuaris del nostre joc.
 *
 */

public class User implements Serializable{
	private String name;
	private String password;
	private int score;
	
	
	
	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	
	/**
	 * Constructor
	 * @param name Nom de l'usuari
	 * @param password La contrasenya de l'usuari
	 * @param score I la puntuacio de l'usuari
	 */

	public User(String name, String password, int score) {
		this.name = name;
		this.password = password;
		this.score = score;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public String getPassword() {
		return password;
	}
	
	public void setPassword(String password) {
		this.password = password;
	}
	
}
