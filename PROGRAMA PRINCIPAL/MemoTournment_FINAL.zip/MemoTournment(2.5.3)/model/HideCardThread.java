package model;
/*Thread per amagar les cartes incorrectes 
 * al passar 1 segon despres de obrir-les.
 * 
 */
import java.applet.AudioClip;

import vista.Scene;
/**
 *Posa boca avall les cartes un cop ja han sigut mostrades
 *
 */
public class HideCardThread implements Runnable  {
	// Temps que les cartes queden destapades
	private static final long sleepTime = 1000;
	private Scene vista;
	private Card[] cartes;
	private Deck llista;

	
	/**
	 * Constructor
	 * @param cartes Quina carta
	 * @param llista Llista on s'hi troben les cartes
	 */
	public HideCardThread(Card[] cartes, Deck llista){
		this.cartes = cartes;
		this.llista = llista;
	}

	public void run() {
		try {
			Thread.sleep(sleepTime);
		} catch (InterruptedException e) {
			System.out.println("Thread Error!");
		}
		for(int i=0; i<llista.getList().size(); i++){
			if(cartes[0].getID() == llista.getList().get(i).getID()){
				llista.getList().get(i).tapa();
			}
			if(cartes[1].getID() == llista.getList().get(i).getID()){
				llista.getList().get(i).tapa();	
				AudioClip sound;
				sound = java.applet.Applet.newAudioClip(getClass().getResource("/images/FAIL.wav") );
				sound.play();
			}
		}
	}

}

