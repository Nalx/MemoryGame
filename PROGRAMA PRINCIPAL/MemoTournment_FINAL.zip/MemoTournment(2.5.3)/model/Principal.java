package model;

import javax.swing.SwingUtilities;

import vista.ChooseRanking;
import vista.Difficulty;
import vista.GameModes;
import vista.InitialMenu;
import vista.MainWindow;
import vista.Ranking;
import vista.RegistreMenu;
import vista.Scene;
import controller.GameModesController;
import controller.LoginController;
import controller.newMouseListener;

/**
 * Classe main del programa en la que s'executara tot el programa.
*/

public class Principal {
	public static void main (String args[]){
		//controlador eiquetes bot�: event.getActionCommand()
		//etiquetar boto/whatever element(el que sigui).setActionCommand("nomEtiquetaControlador")
		
		/*Per posar els elements al pixel que vulguis i la mida que vulguis: 
		setLayout(null)
		element.setBounds(x,y,amplada,al�ada)*/
		
		SwingUtilities.invokeLater(new  Runnable() {
			
			@Override
			public void run() {
				
				MainWindow w = new MainWindow();
				
				InitialMenu iView = new InitialMenu();
				LoginController lController = new LoginController(w, iView);
				iView.establishController(lController);
				w.addInitialMenu(iView);
				w.showInitialMenu();
			
				
				w.setVisible(true);
				
			}
		});
			
	}
}
