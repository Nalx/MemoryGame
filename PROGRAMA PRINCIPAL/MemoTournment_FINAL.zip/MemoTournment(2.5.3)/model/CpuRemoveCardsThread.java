package model;

import vista.Scene;
/**
 * Classe que s'encarrega d'implemetar un Thread per a deixar de fer visibles les cartes del taulell.
*/

public class CpuRemoveCardsThread implements Runnable{
	private static final long sleepTime = 5000;
	private Scene vista;
	private Card carta;
	private Deck llista;
	private int macScore;
	
	/**
	 * Controlador de la classe CpuRemoveCardsThread, s'encarrega de setejar els valors dels parametres de la 
	 * classe amb els valors que es passin per parametres al constructor.
	 * @param carta Objecte de la classe carta que es vol remoure, fer no visible.
	 * @param llista Objecte de classe Deck amb una series de cartes.
	 */
	public CpuRemoveCardsThread (Card carta, Deck llista, Scene vista, int macScore){
		this.carta = carta;
		this.llista = llista;
		this.vista = vista;
		this.macScore = macScore;
	}
	
	/**
	 * Quan s'executa el Thread es deixen de fer visibles totes les cartes de la Deck atribut de la classe.
	 */
	public void run() {
		try {
			Thread.sleep(sleepTime);
		} catch (InterruptedException e) {
			System.out.println("Thread Error!");
		}
		for(int i=0; i<llista.getList().size(); i++){
			if(carta.getID() == llista.getList().get(i).getID()){
				llista.getList().get(i).setVisible(false);
			}
		}
		if (macScore != -1){
			vista.updateScoreCPU(macScore);
		}
	}
}
