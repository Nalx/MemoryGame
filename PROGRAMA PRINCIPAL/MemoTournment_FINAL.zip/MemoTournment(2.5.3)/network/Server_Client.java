package network;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.net.UnknownHostException;
import java.util.LinkedList;

import model.User;
import controller.GameModesController;
import controller.LoginController;
import controller.newMouseListener;

/**
 * Implementa les operacions de connexi� amb el Servidor per part del client.
 * Envia la informaci� que pertoca al servidor i implementa les connexions   que
 * siguin necess�ries per pasar la informaci� al servidor.
 */

public class Server_Client{
	
	private Socket sClient;
	private ObjectInputStream oiStream;
	private ObjectOutputStream ooStream; 
	private DataOutputStream doStream;
	private DataInputStream diStream;
	private static final String IP = "localhost";
	private static final int PORT = 55555;
	private LoginController lc;
	private newMouseListener mc;
	private GameModesController gc;

	/**
	 * Constructor de la classe Server_client, s'encarrega de setejar els valors de 
	 * la classe amb els valors que es passen per parametres.
	 * @param c Classe LoginController associada a la vista del client.
	 * @param mc Classe MouseListener associada al joc
	 * @param gc Classe que controla la vista de modes de joc.
	 */

	public Server_Client(LoginController c, newMouseListener mc, GameModesController gc){
		this.lc = c;
		this.mc = mc;
		this.gc = gc;
	}
	
	
	
	
	
	/**
     * Classe encarrega de enviar la informacio del String rebut per paramtre al Servidor. A m�s la 
     * classe fa diferents comportaments segons el valor rebut a la cadena s.
	 * @param u Classe User de l'usuari a mostrar o llegir informaci�.
	 * @param s String que rebra el servidor i amb el que s'executaren diverses accions segons el valor d'aquest.
	 * @param aux String amb el valor del ranking a buscar.
	 */
	
	/*
	 * Per a cada vegada que fem click a send, el controlador ens passar� el String a enviar
	 * Obrirem connexi� amb el Servidor mitjan�ant el Socket sClient (establirem el socket)
	 * Crearem un nou fluxe per a enviar informaci� per aquest socket
	 * Enviarem el String (UTF)
	 * Tancarem el socket
	 * */
	public void dataStream(User u, String s, String aux){
		String ret = "Communication Error!";
		try {	
			sClient = new Socket(IP, PORT);
			
			//Enviem un String fem refer�ncia a la info que enviarem a continuaci�
			doStream =  new DataOutputStream(sClient.getOutputStream());
			doStream.writeUTF(s);
			
			if (s.equals("Login")){
				ret = checkUser(u);
				lc.setResult(ret);
			}
			
			if (s.equals("Rank")){
				System.out.println("Before");
				LinkedList <User> list = getRanking(aux);
				System.out.println("after");
				gc.setList(list);
				System.out.println("End");
				
			}
			
			if (s.equals("New")){
				newUser(u);
			}
			
			if (s.equals("Update")){
				update(u.getScore(), u.getPassword());
			}
			
			//c.errorMessage("\nMisstage enviat:\n" + s);
			sClient.close();
		} catch (UnknownHostException e) {
			//c.errorMessage("Couldn't connect with the Server!");
		} catch (IOException e) {
			//c.errorMessage("Couldn't connect with the Server!");
		}
		
	}

	/**
	 * Classe encarregada de actualitzar informaci� del usuari guest.
	 * @param points punts que tindr� aquest usuari
	 * @param mode Mode de joc enel que es troba jugant
	 * @return Retorna una cadena amb el missatge, segons si la conexio ha estat satisfactoria.
	 */

	public String update(int points, String mode){
		String result = "";
		mc.setResult("");
		//Comprovem si es guest User o no
		if (lc.getUName() != null && !lc.getUName().equals("")){
				try {
				result = "Connection Error!";
				//enviem nom i puntuaci� usuari
				ooStream = new ObjectOutputStream(sClient.getOutputStream());
				ooStream.writeObject(new User(lc.getUName(),mode,points));
				
				diStream = new DataInputStream(sClient.getInputStream());
				result = diStream.readUTF();
				
				mc.setResult(result);
			} catch (IOException e) {
				mc.errorMessage("Connection Failed");
			}
		}
		return result;
	}
	
	/**
	 * Clase encarregada de retornar el ranking de tots els jugadors de la bases de dades
	 * segons el mode de joc que es desitgi.
	 * @param mode String amb el mode de joc del qual es vol saber el ranking
	 * @return Retorna una LinkedList de usuaris amb els rankings del jugadors segons el mode de joc enviat.
	 */

	public LinkedList<User> getRanking(String mode){
		LinkedList<User> list = new LinkedList<User>();
		try {
			
			doStream = new DataOutputStream(sClient.getOutputStream());
			doStream.writeUTF(mode);
			
			
			oiStream = new ObjectInputStream(sClient.getInputStream());	
			list = (LinkedList <User>) oiStream.readObject();
			return list;
		} catch (IOException e) {
			lc.errorMessage("No data foundIO");
		} catch (ClassNotFoundException e) {
			lc.errorMessage("No data foundCNF");
		}
		
		return list;
		
	}
	
	/**
	 * Classe encarrega de passar al servidor un objecte del tipus User per
	 * a que aquest el registri a la base de dades.
	 * @param u Objecte de la classe Usuari que es vol passar al Servidor.
	 */

	public void newUser(User u){
		String result = "Connection Error!";
		try {
			//Enviem l'usuari a actualitzar
			ooStream = new ObjectOutputStream(sClient.getOutputStream());
			ooStream.writeObject(u);
			
			//Rebem feedback de la inserci� del nou usuari
			diStream = new DataInputStream(sClient.getInputStream());
			result = diStream.readUTF();
			
			lc.setResult(result);
		} catch (IOException e) {
			lc.errorMessage("Connection Failed");
		}
		
	}
	
	/**
	 * Comproba si l'usuari enviat es troba al Servidor i mostra el missatge
	 * pertinent segons si es troba o no.
	 * @param u Objecte de la classe Usuari del qual es vol saber si es troba al servidor.
	 * @return Retorna un String amb la resposta del chequeig del Usuari enviat.
	 */
	public String checkUser(User u){
		String ret = "Communication error!";
		try {
			ooStream = new ObjectOutputStream(sClient.getOutputStream());
			ooStream.writeObject(u);
			
			diStream = new DataInputStream(sClient.getInputStream());
			ret = diStream.readUTF();
			return ret;
			
		} catch (IOException e) {
			//c.errorMessage("Couldn't connect with the Server!");
		}
		return ret;
	}
	
}