package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JButton;
import javax.swing.Timer;

import model.ArtificialInteligence;
import model.Card;
import model.Countdown;
import model.CpuHideCardsThread;
import model.CpuRemoveCardsThread;
import model.CpuShowCardsThread;
import model.HideCardThread;
import model.Logica;
import model.RemoveCardsThread;
import model.SceneThread;
import model.User;
import network.Server_Client;
import vista.ErrorWindow;
import vista.MainWindow;
import vista.Scene;


/**
 * Controlador que controla el comportament del mouse a la pantalla de joc del memori. Aquesta classe s�encarrega de gestionar el
 *  que faran les cartes un cop l�usuari les hagi premut amb el mouse. Tamb� conte m�todes que gestionen el comportament de les 
 *  cartes un cop es el torn de la maquina. Gestiona el Thread de la vista del joc (Scene)
 */

public class newMouseListener implements MouseListener, ActionListener  {

	private ArtificialInteligence aiLogica;
	private Countdown countdown;
	private Scene vista;
	private Logica logica;
	private Server_Client serv;
	private String result;
	private MainWindow w;
	private String gameMode;
	private int torn;
	private int messageFlag;
	private long sleepTime;
	private int multiplier;

	/**
	 * Aquesta funcio es la que inicia el joc segons el mode de joc, si es Memory mode o Concentracio iniciara el contrarellotge, si es
	 * Concentracio ensenyara les cartes inicials, i si es CPU iniciara la inteligencia artificial.
	 * 
	 * @param vista La clase amb la vista del joc i les funcions per a modificar el temps, les cartes, etc.
	 * @param w Vista principal amb el cardLayout que controla quan es veuen els panells.
	 * @param difficulty Un int que designa la dificultat del joc.
	 * @param lController La clase que controla tot el proces de login i de registre (Sign in)
	 * @param gameMode String que designa el mode de joc que ha escogit l'usuari.
	 */

	public newMouseListener(Scene vista, MainWindow w, int difficulty, LoginController lController, String gameMode){
		this.vista = vista;
		this.logica = new Logica(difficulty);
		serv = new Server_Client(lController, this, null);
		this.w = w;
		this.gameMode = gameMode;
		messageFlag=0;
		
		switch(difficulty){
		case 1:
			multiplier = 100;
			break;
		case 2:
			multiplier = 200;
			break;
		case 3:
			multiplier = 300;
			break;
		}
		
		
		
		if (gameMode.equals("Memo") || gameMode.equals("Conc")){
			this.countdown = new Countdown(difficulty, this);
			this.countdown.timeStart();
		}
		if (gameMode.equals("Conc")){
			vista.showInitalCards();
			switch(difficulty){
			case 1:
				sleepTime = 5000;
				break;
			case 2:
				sleepTime = 2000;
				break;
			case 3: 
				sleepTime = 1000;
				break;
			}
			new Thread(new SceneThread(vista.getDeck(),vista,sleepTime)).start();
		}

		if (gameMode.equals("Cpu")){
			aiLogica = new ArtificialInteligence(difficulty, vista.getDeck());
		}
		torn = 0;

	}

	/**
	 * Clase que reacciona quan el timer o el boto li diu, si el timer ha acabat surt un missatge que diu que has perdut i es para
	 * el temps, a mes de tornar a la pantalla inicial. Si s'ha clickat el boto i la conta enrera esta en marcha es para el temps i 
	 * es mostra el menu. 
	 */

	public void setResult(String result){
		this.result = result;
	}

	/**
	 * Clase que reacciona quan el timer o el boto li diu, si el timer ha acabat surt un missatge que diu que has perdut i es para
	 * el temps, a mes de tornar a la pantalla inicial. Si s'ha clickat el boto i la conta enrera esta en marcha es para el temps i 
	 * es mostra el menu. 
	 */

	@Override
	public void actionPerformed(ActionEvent e) {
		if( e.getSource() instanceof Timer){
			String s=countdown.updateActualTime();
			vista.updateClock(s);
			if(countdown.endTime() && messageFlag == 0){
				errorMessage("YOU LOSE!");
				countdown.timeStop();
				w.showGameModes();
				messageFlag = 1;
			}

		}

		if (e.getSource() instanceof JButton){
			w.showGameModes();
			if (countdown != null){
				countdown.timeStop();

			}
		}


	}

	/**
	 * Crea i mostra una finestra d'error amb el missatge que vulguis.
	 * @param s Es el missatge d'error que vols que es mostri
	 */

	public void errorMessage(String s){
		ErrorWindow ew = new ErrorWindow (s);
		ew.show();
	}


	/**
	 * Detecta quan es clicka el ratoli i segons on s'hagi clickat fa una cosa o una altra.
	 */

	public void mousePressed(MouseEvent arg0) {

		//ATOI de el nombre1
		int x1= 0;
		//ATOI de el nombre2
		int x2 = 0;
		String s = "";

		//Mirem si s'ha fet click a una newJLabel
		if (arg0.getSource() instanceof Card) {
			//TORN USER-----------------
			s = logica.addCard(new Card(((Card)arg0.getSource()).getID(), ((Card)arg0.getSource()).getName()));		
			vista.destapa(((Card)arg0.getSource()).getID(), Integer.parseInt(((Card)arg0.getSource()).getName()));
			//--------------------------
			if (s.equals("Correct")){
				torn++;
	
				
				if (gameMode.equals("Cpu")){
					vista.updateScore(logica.getnPunts()); 
					aiLogica.IncrementUserScore();
				}

				new Thread(new RemoveCardsThread(logica.getCardPair(),vista.getDeck())).start(); 
				if (gameMode.equals("Cpu")){
					if(aiLogica.endGame()){
						System.out.println("End GAME!");
					}else{
						tornMaquina(s);
					}
				}
				if (logica.finished()){
					vista.winMessage();

					if(countdown != null){
						countdown.timeStop();
					}

					int points = 0;
					if (gameMode.equals("Memo")){
						points = countdown.getScore();
						vista.updateScore(points);
						serv.dataStream(new User("", "memo", points), "Update", "");		
					}
					if (gameMode.equals("Conc")){
						points = countdown.getScore();
						vista.updateScore(points);
						serv.dataStream(new User("", "conc", points), "Update", "");
					}
					if(!gameMode.equals("Cpu")){
						if ( (result == null || result.equals("")) ){
							errorMessage("YOU WIN!\n" + points + "points");
							messageFlag = 1;
						}
						else{
							errorMessage(result);
						}
						w.showGameModes();				
					}
					if (logica.finished()){
						if (gameMode.equals("Cpu") && messageFlag == 0){
							if (aiLogica.getUserScore() > aiLogica.getMachineScore()){
								points = logica.getnPunts();
								errorMessage("1.YOU WIN!\n" + points*multiplier + " Points");
								serv.dataStream(new User("", "cpu", points*multiplier), "Update", "");
								messageFlag = 1;
							}
							if (aiLogica.getUserScore() <= aiLogica.getMachineScore() && messageFlag == 0){
								points = aiLogica.getUserScore();
								errorMessage("You Lose!\n" + points*multiplier + " Points");
								messageFlag = 1;
							}
						}
						messageFlag=1;
						w.showGameModes();
					}
				}
			}
			if (s.equals("Wrong")){
				torn++;
				new Thread(new HideCardThread(logica.getCardPair(),vista.getDeck())).start();	
				if(gameMode.equals("Cpu")){
					if(!aiLogica.endGame()){
						tornMaquina(s);	
					}

				}
			}	
		}

	}

	/**
	 * Fa el torn de la maquina tot comparant les cartes i comprovant si ha guanyat algu. Incrementa les puntuacions i actualitza el 
	 * servidor.
	 * @param s String que indica si es Correct, Wrong o Same.
	 */

	public void tornMaquina(String s){
		//TORN CPU---------------------
		int points = 0;
		//Si l'usuari ha encertat:
		if (s.equals("Correct")){
			aiLogica.setUserChosenCards(logica.getCardID());
			aiLogica.setUserChosenCards(logica.getCardID());	
		}
		Card array[] = new Card [2];
		array = aiLogica.chooseCard();
		if (array != null){
			new Thread(new CpuShowCardsThread(array[0], vista,vista.getDeck())).start();
			new Thread(new CpuShowCardsThread(array[1], vista,vista.getDeck())).start();
		}
		torn++;
		//BE:)
		if(aiLogica.compareCards(array)){		
			logica.IncrementCorrectCards();
			System.out.println("Points= "+points);
			if (logica.finished()){
				if (gameMode.equals("Cpu") && messageFlag==0){
					if (aiLogica.getUserScore() > aiLogica.getMachineScore()){
						points = aiLogica.getUserScore();
						errorMessage("YOU WIN!\n" + points*multiplier + " Points");
						serv.dataStream(new User("", "cpu", points*multiplier), "Update", "");
						messageFlag = 1;
					}
					if (aiLogica.getUserScore() <= aiLogica.getMachineScore() && messageFlag == 0){
						points = aiLogica.getUserScore();
						errorMessage("You Lose!\n" + points*multiplier + " Points");
						messageFlag = 1;
					}
				}

				if (result == null || result.equals("")){

				}
				else{
					errorMessage("HOLA" + result);
				}
				w.showGameModes();
			}
			new Thread(new CpuRemoveCardsThread(array[0],vista.getDeck(), vista, -1)).start(); 
			new Thread(new CpuRemoveCardsThread(array[1],vista.getDeck(), vista, aiLogica.getMachineScore()*multiplier)).start();
			System.out.println("\n\n\n" + aiLogica.getMachineScore());
		}
		//MAL
		else{		
			System.out.println("maquina Error!!!!!!!!!!!!!!!!!!");
			new Thread(new CpuHideCardsThread(array[0],vista, vista.getDeck())).start();
			new Thread(new CpuHideCardsThread(array[1],vista, vista.getDeck())).start();
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {}

	@Override
	public void mouseEntered(MouseEvent e) {}

	@Override
	public void mouseExited(MouseEvent e) {}

	@Override
	public void mouseReleased(MouseEvent e) {}
}
