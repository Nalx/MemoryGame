package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

import model.User;
import network.Server_Client;
import vista.ChooseRanking;
import vista.Difficulty;
import vista.ErrorWindow;
import vista.MainWindow;
import vista.MemoConc;
import vista.Raiting;
import vista.Ranking;
import vista.Scene;



/**
 * Classe controladora que s�encarrega d�implementar els controladors de la vista dels modes de joc. 
 * Amb aquest controlador el programa fara el que pertoqui quan l�usuari seleccioni un dels modes de
 * joc disponibles. Implementa m�todes que gestionen  el que es realitzar� amb el controlador quan
 * l�usuari seleccioni una vista de la vista principal. 
 */

public class GameModesController implements ActionListener{
	
	private MainWindow w;
	private Scene sceneView;
	private newMouseListener mController;
	private String gameMode;
	private Server_Client server;
	private LoginController lController;
	private LinkedList <User> list;
	private Ranking rankView;
	private ChooseRanking crView;
	private Raiting infoView;
	
	
	private MemoConc mc;
	
	private MemoConc mcView; 
	
	private Difficulty dView;
	
	public GameModesController(MainWindow w, LoginController lController){
		gameMode ="";
		this.w = w;
		
		dView = new Difficulty();
		dView.setController(this);
		
		this.lController = lController;
		server = new Server_Client(lController, null, this);
		
		
		crView = new ChooseRanking();
		crView.setController(this);
		
		mc = new MemoConc();
		mc.setController(this);
		
		rankView = new Ranking();
		rankView.establishController(this);
		
		infoView = new Raiting();
		infoView.establishController(this);
		
		w.addRating(infoView);
		w.addMemoConc(mc);
		w.addChooseRanking(crView);
		w.addRanking(rankView);
		w.addDifficulty(dView);
	}
	
	
	/**
	 * Classe que mostra un element interactiu amb missatge de error per pantalla.
	 * @param s Cadena de caracters per on es passara el missatge d'error que apareixera per pantalla.
	 */

	public void errorMessage(String s){
		ErrorWindow ew = new ErrorWindow (s);
		ew.show();
	}

	/**
	 * Classe que seteja el valor de la LinkedList atribut de la classe amb el
	 * valor que es passi per parameters.
	 * @param list LinkedList que es copiara per al atribut de la classe.
	 */

	public void setList(LinkedList <User> list){
		this.list = list;
	}
	
	/**
	 * Classe que s'encarrega de executar els comportaments adients segons el element de la vista amb
	 * el que el jugador ha interactuat. 
	 */
	public void actionPerformed(ActionEvent e) {
		
		
		//DIFFICULTY VIEW----------------------------------------------------------
		if (e.getActionCommand().equals("Easy")){
			sceneView = new Scene(1,gameMode);
			mController = new newMouseListener(sceneView, w, 1, lController, gameMode);
			sceneView.establishController(mController);
			w.addScene(sceneView);
			w.showScene();
		}
		if (e.getActionCommand().equals("Normal")){
			sceneView = new Scene(2,gameMode);
			mController = new newMouseListener(sceneView, w, 2, lController, gameMode);
			sceneView.establishController(mController);
			w.addScene(sceneView);
			w.showScene();
		}
		if (e.getActionCommand().equals("Hard")){
			sceneView = new Scene(3,gameMode);
			mController = new newMouseListener(sceneView, w, 3, lController, gameMode);
			sceneView.establishController(mController);
			w.addScene(sceneView);
			w.showScene();
		}
		//----------------------------------------------------------------------------
		
		//GAMEMODES VIEW-----------------------------------------------
		if (e.getActionCommand().equals("Trial")){
			w.showMemoConc();
		}
		if (e.getActionCommand().equals("Cpu")){
			gameMode = "Cpu";
			w.showDifficulty();
		}
		
		if (e.getActionCommand().equals("Ranking")){
			w.showChooseRanking();
		}
	
		if (e.getActionCommand().equals("Logout")){
			w.showInitialMenu();
		}
		
		if (e.getActionCommand().equals("Info")){
			w.showRating();
		}
		//-----------------------------------------------
		
		
			if (e.getActionCommand().equals("BackR")){
				w.showGameModes();
			}
		
		
		
		//RANK & CHOOSERANK------------------------------------
		if (e.getActionCommand().equals("Back")){
			w.showGameModes();
		}
		
		//Concentration Rank
		if (e.getActionCommand().equals("Conc")){
			server.dataStream(null, "Rank", "conc" );
			if (list == null || list.size() == 0){
				errorMessage("Not data found!");
			}else{
				
				rankView.setTextRanking(list);
				w.showRanking();
			}
			
		}
		//Memory Rank
		if (e.getActionCommand().equals("Memo")){
			server.dataStream(null, "Rank", "memo" );
			if (list == null || list.size() == 0){
				errorMessage("Not data found!");
			}else{
				
				rankView.setTextRanking(list);
				w.showRanking();
			}
			
		}
		
		if (e.getActionCommand().equals("Return")){
			w.showGameModes();
			
		}
		
		if (e.getActionCommand().equals("Contra")){
			server.dataStream(null, "Rank", "cpu" );
			if (list == null || list.size() == 0){
				errorMessage("Not data found!");
			}else{
				
				rankView.setTextRanking(list);
				w.showRanking();
			}
		}
		//--------------------------------------------------
		
		//MEMORY OR CONCERTATION GAME MODE-----
		if (e.getActionCommand().equals("Memory")){
			w.showDifficulty();
			gameMode = "Memo";
		}
		if (e.getActionCommand().equals("Concentration")){
			
			w.showDifficulty();
			gameMode = "Conc";
		}
		//------------------------------------------
	}
}
