package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.LinkedList;

import model.User;
import network.Server_Client;
import vista.ErrorWindow;
import vista.GameModes;
import vista.InitialMenu;
import vista.MainWindow;
import vista.RegistreMenu;


/**
 * Controla que, al entrar el login, aquest sigui correcte mitjancant una connexio amb una base de dades on s'hi guarden els diferents usuaris.
 * S'hi podran crear nous usuaris o be jugar amb usuaris ja registrats, aixo depen de la opcio que el jugador trii al menu.
 *
 */
public class LoginController implements ActionListener {
	private InitialMenu initialView;
	private MainWindow w;
	private RegistreMenu registreView;
	Server_Client server;
	private GameModes gmView;
	private GameModesController gController;
	private String uName;
	
	private String result;
	private LinkedList <User> list;
	
	/**
	 * Constructor
	 * @param w Finestra on es desarollen les vistes
	 * @param initialView Aquesta vista mostra el menu amb les diferents opcions que el jugador pot triar per a tot el tema de jugar com a usuari.
	 */
	public LoginController(MainWindow w, InitialMenu initialView){
		uName = "";
		this.initialView = initialView;
		this.registreView = new RegistreMenu();
		
		this.gmView = new GameModes();
		this.w = w;
		this.server = new Server_Client(this, null,null);
		this.result = "Connection Failed!";
		this.gController = new GameModesController(w, this);
		
		registreView.establishController(this);
		gmView.establishController(gController);
		w.addGameModes(gmView);
		w.addRegistreMenu(registreView);
	}
	
	public void setResult (String result){
		this.result = result;
	}
	
	public void setList(LinkedList<User> list){
		this.list = list;
	}
	
	
	public String getUName(){
		return uName;
	}
	
	/**
	 * Mostra una nova finestra amb el missatge d'error que rep
	 * @param s Missatge d'error
	 */
	public void errorMessage(String s){
		ErrorWindow ew = new ErrorWindow (s);
		ew.show();
	}
	
	
	/**
	 * Segons la opcio que el jugador hagi triat al menu InitialMenu, l'event a dur a terme sera un o altre.
	 * Si l'usuari es vol registrar (Register) el metode connecta amb la base de dades i l'afegeix. I, en canvi, ja esta registrat i vol entrar a la seva
	 * conta (Login), el metode tambe connecta amb la base de dades i comprova que existeix.
	 * Tamb� hi ha altres opcions al menu com Restore, Cancel, Sign In, Guest User o Exit, aquests events no necesiten connectar amb cap base de dades, i el metode
	 * funciona correctament per a cada una de les opcions.
	 * @param e Event que ens serveix per a saber quina opcio a triat el jugador.
	 */

	@Override
	public void actionPerformed(ActionEvent e) {
		
	//REGISTRE---------------------------------------------------------------
		if (e.getActionCommand().equals("Register")){
			
			server.dataStream(new User(registreView.getTypedName(), registreView.getTypedPassword(),0),"New", "");
			
			
			if (result.equals("")){
				w.showGameModes();
				uName = registreView.getTypedName();
			}else{
				errorMessage(result);
			}
		}
		
		if (e.getActionCommand().equals("Restore")){
			registreView.setTypedName("");
			registreView.setTypedPassword("");
		}
		
		if (e.getActionCommand().equals("Cancel")){
			w.showInitialMenu();
		}
	//-------------------------------------------------------
		
		
	//INITIAL-------------------------------------------------------------------------
		//LOGIN------------------------------------------------------------------------
		if (e.getActionCommand().equals("Login")){
			server.dataStream(new User(initialView.getTypedName(), initialView.getTypedPassword(), -1), "Login", "");
			
			if (result.equals("")){
				w.showGameModes();
				uName = initialView.getTypedName();
			}
			else{
				errorMessage(result);
			}
			
	
		}
		//--------------------------------------------------------------------------------
		//SIGN IN-----------------------------------
		if (e.getActionCommand().equals("Sign In")){
			w.showRegistreMenu();
		}
		//---------------------------------------
		
		//GUEST USER-----------------------------------
		if (e.getActionCommand().equals("Guest User")){
			w.showGameModes();
			uName = "";
		}
		//---------------------------------------
		
		//EXIT-----------------------------------
		if (e.getActionCommand().equals("Exit")){
			System.exit(0);
		}
		//---------------------------------------
	//---------------------------------------------------------------------------------------
		
		
		
	}
	
}
