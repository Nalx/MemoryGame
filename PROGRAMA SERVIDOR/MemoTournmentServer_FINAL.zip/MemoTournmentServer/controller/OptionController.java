package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;

import model.User;
import network.DBOperations;
import network.Server;
import view.GraficArrays;
import view.OptionMenu;
import view.Ranking;
import view.ServerWindow;
/**
 * Aquesta classe exerceix de controlador per la part del programa en que el servidor ja esta inicialitzat.
 * Implementa ActionListener ja que escoltara aquests esdeveniments de les seves vistes corresponents.
 *
 */
public class OptionController implements ActionListener{

	private OptionMenu omView;
	private DBOperations dbOps;
	private Server server;
	private ServerWindow w;
	GraficArrays gaView;
	
	/**
	 * Constructor.
	 * @param omView OptionMenu, menu que es mostra un cop s'ha establert connexio amb la base de dades.
	 * @param w ServerWindow, finestra principal del programa.
	 */
	public OptionController(OptionMenu omView, ServerWindow w){
		this.omView = omView;
		this.w = w;
		dbOps = new DBOperations(this);
	}
	
	/**
	 * Permet mostrar missatges per la consola d'OptionMenu.
	 * @param s Missatge a mostrar
	 */
	public void showMessage(String s){
		omView.setCommandText(omView.getCommandText() + "\n\n" +s);
	}
	
	/**
	 * Obte el temps actual.
	 * @return Temps actual en format d'String.
	 */
	public String getTime(){
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Date time = new Date();
		return dateFormat.format(time);
	}
	
	/**
	 * Metode que rep eles esdeveniments de tipus actionEvent d'OptionMenu i de la vista del Grafic.
	 * 
	 * Si s'apreta el boto User, s'agafaran les dades introduides als corresponents textfields i s'intentar� inserir el nou usuari.
	 * Es mostrara un missatge per la consola d'OptionMenu tant si s'ha realitzat correctament com si no.
	 * 
	 * Si es prem ranking, es mostrar� el ranking de la modalitat escollida. 
	 * Si la modalitat no existeix o no hi ha usuaris registrats encara, es mostrar� misstage d'error.
	 * 
	 * Pel boto Graph, es mostrara un grafic amb l'evolucio de puntuacions de l'usuari introduit (mostrant la vista corresponent).
	 * Si l'usuari no existeix, es mostrara missatge d'error.
	 * 
	 * Si, estant a la vista del grafic, es prem Back, tornarem a mostrar OptionMenu.
	 * 
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		
		
		if (e.getActionCommand().equals("User")){
			System.out.println("New User:" + omView.getNewUser()+ "|" + omView.getNewPassword());
			String s = dbOps.addUser(new User(omView.getNewUser(), omView.getNewPassword(),-1));
			if (s.equals("")){
				showMessage(getTime()+": Successfully added new user -->" + omView.getNewUser() + "||" +omView.getNewPassword());
			}
			else{
				showMessage(getTime()+": " + s);
			}
			
		}
		
		
		if (e.getActionCommand().equals("Ranking")){
			System.out.println("Ranking");
			System.out.println(omView.getTypedModeRank());
			LinkedList<User> list = dbOps.getRanking(omView.getTypedModeRank());
			if (list == null || list.size() == 0){
				showMessage("No data found!");
			}
			else{
				Ranking rView = new Ranking(omView.getTypedModeGraph());
				rView.setController(this);
				rView.setRankingText(list);
				w.addRanking(rView);
				w.showRanking();
			}
		}
		
		if (e.getActionCommand().equals("Graph")){
			System.out.println("Graph");
			System.out.println(omView.getGraphUser() + omView.getTypedModeGraph());
			LinkedList <Integer> list = dbOps.getUserGraphList(omView.getGraphUser(), omView.getTypedModeGraph());
			if (list == null || list.size() == 0){
				showMessage(getTime()+ ": No data found!");
			}
			else{
				
				gaView = new GraficArrays(list, omView.getGraphUser());
				gaView.setController(this);
				w.addGraph(gaView);
				w.showGraph();
			}
			
		}
		
		if (e.getActionCommand().equals("Back")){
			w.showOptionMenu();
		}
	}

}
