package controller;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import network.DBOperations;
import network.Server;
import view.CustomConnectionView;
import view.ErrorWindow;
import view.InitialView;
import view.OptionMenu;
import view.ServerWindow;

/**
 * Classe controladora que s'encarrega de la part en que el servior encara no esta actiu (configuracio de la connexio).
 * Implementa ActionListener ja que escoltar� el tipus d'esdeveniments ActionEvents.
 *
 */
public class ConnectionController implements ActionListener{
	private ServerWindow sWindow;
	private CustomConnectionView ccView;
	private DBOperations dbOp;
	private InitialView iView;
	private OptionMenu omView;
	private Server server;
	
	/**
	 * Constructor.
	 * @param sWindow ServerWindow, finestra principal del programa
	 * @param ccView CustomConnectionView, vista on es poden modificar les dades de la connexi�.
	 * @param iView InitialView, vista on s'escull si realitzar una connexio per defecte o personalitzada.
	 * @param omView OptionMenu, vista que s'obrir� un cop el servidor s'inicialitzi.
	 */
	
	public ConnectionController(ServerWindow sWindow, CustomConnectionView ccView, 
			InitialView iView, OptionMenu omView){
		
		this.sWindow = sWindow;
		this.ccView = ccView;
		this.iView = iView;
		this.omView = omView;
		dbOp = new DBOperations();
		server = new Server(this);
	
	}
	
	/**
	 * Permet mostrar missatges per la consola d'OptionMenu.
	 * @param s Missatge a mostrar
	 */
	public void showMessage(String s){
		omView.setCommandText(omView.getCommandText() + "\n\n" + s);
	}
	
	/**
	 * Obte el temps actual.
	 * @return Temps actual en format d'String.
	 */
	public String getTime(){
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Date time = new Date();
		return dateFormat.format(time);
	}
	
	
	/**
	 * Procediment que rep els actionEvents de les vistes corresponents.
	 * 
	 * INITIAL VIEW:
	 * Si es prem el boto de default connection, es prova la connexio a la base de dades amb les dades per defecte.
	 * Si la connexio es correcta, es mostra l'optionMenu. Sino, es mostra missatge d'error.
	 * 
	 * Si es prem el boto de Custom, s'accedeix a ccView.
	 * 
	 * CUSTOM CONNECTION
	 * Si es prem el boto Restore, les dades tornen al seu valor per defecte.
	 * Si es prem el boto Connect, es prova la connexio amb les dades actuals.
	 * Si es correcta, s'accedeix al OptionMenu. Sino, es mostra missatge d'error.
	 * 
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		
		//INITIAL VIEW------------------------------------
			if (e.getActionCommand().equals("Default")){
				try {
					dbOp.test();
					sWindow.showOptionMenu();
					showMessage(getTime()+": Database connection successfully tested!");
					server.connect();
					showMessage(getTime()+": Server Started!");
				} catch (SQLException e1) {
					ErrorWindow.show("Could not access to dpo database!\n");
					
				} catch (ClassNotFoundException e1) {
					ErrorWindow.show("Could not access to dpo database!\n");
				}
			}
			if (e.getActionCommand().equals("Custom")){
				sWindow.showCustomConnectionView();
			}
		//----------------------------------------------	
		
		//CUSTOM CONNECTION----------------------------------------------------------------
		if(e.getActionCommand().equals("Restore")){
			System.out.println("HALLo");
			ccView.setDefaultValues();
		}
		if (e.getActionCommand().equals("Connect")){
			dbOp.setValues(ccView.getTypedDB(), ccView.getTypedUser(), ccView.getTypedPassword(), ccView.getIntPort());
			dbOp.getDBConnection().showValues();
			server.connect();
			dbOp.getDBConnection().showValues();
			showMessage(getTime()+": Server Started!");
			dbOp.getDBConnection().showValues();
			try {
				dbOp.getDBConnection().showValues();
				dbOp.test();
				sWindow.showOptionMenu();
				showMessage(getTime()+": Database connection successfully tested!");
			} catch (SQLException e1) {
				ErrorWindow.show("Could not connect to " + ccView.getTypedDB() + " database!");
			} catch (ClassNotFoundException e1) {
				ErrorWindow.show("Could not connect to " + ccView.getTypedDB() + " database!");
			}
			
			
			
		}
		//------------------------------------------------------------------------------------
		
		 
	}
	
	

}
