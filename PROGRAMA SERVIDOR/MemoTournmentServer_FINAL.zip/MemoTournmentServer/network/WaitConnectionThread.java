package network;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.LinkedList;

import model.User;

/**
 * Aquesta classe exerceix de thread que es crear� cada vegada que un client envii una peticio de connexio al servidor
 *
 */

public class WaitConnectionThread implements Runnable{

	
	private Server server;
	private ServerSocket sServer;
	private Socket sClient;
	private boolean active;
	private ObjectInputStream oiStream;
	private DBOperations dbOps;
	private DataInputStream diStream;
	private DataOutputStream doStream;
	private ObjectOutputStream ooStream;
	
	/**
	 * Rebem la classe Server per a poder enviar-li els missatges que rebem del client
	 * Rebem ServerSocket per a poder fer el .accept();
	 * */
	 
	public WaitConnectionThread(Server s, ServerSocket ss){
		this.server = s;
		this.sServer = ss;
		dbOps = new DBOperations();
		active = true;
		
	}
	
	
	
	/**
	 * Mentre el servidor estigui actiu, 
	 * 1.- Escoltem les peticions del Client (establim socket)
	 * 2.- Creem DataInputStream per poder rebre informaci� del client
	 * 3.- Llegim la informacio del client (String = UTF)
	 * 4.- Enviem la informaci� al thread principal (Server)
	 * 5.-Tanquem connexi� amb client (tanquem socket)
	 * 
	 */
	@Override
	public void run() {
		
		while (active){
			
			try{
				sClient = sServer.accept();
				diStream = new DataInputStream(sClient.getInputStream());
				String s = diStream.readUTF();
				
				if (s.equals("Login")){
					checkUser();
				}
				
				if (s.equals("Rank")){
					System.out.println("HALLO");
					getRank();
				}
				
				
				if (s.equals("New")){
					setNew();
				}
				
				if (s.equals("Update")){
					update();
				}
				
				sClient.close();
			}catch (IOException e){
				server.showMessage(server.getTime() + ": Communication error readUTF");
			}
				
		}
		
		
	}
	
	/**
	 * Per actualitzar el registre de puntuacions d'un usuari.
	 * Rebem l'usuari a actualitzar mitjan�ant oiStream i ho actualitzem a la base de dades.
	 * Retornem un String (doStream) segons si l'operacio ha estat o no exitosa.
	 */
	public void update(){
		try{
			
			oiStream = new ObjectInputStream(sClient.getInputStream());
			User u = (User)oiStream.readObject();
			server.showMessage(server.getTime() + ": User to update:\n" + u.getName() + "||" + u.getScore() + "||" + u.getPassword());
			
			
			String s = "";
			s = dbOps.update(u);
			doStream = new DataOutputStream(sClient.getOutputStream());
			doStream.writeUTF(s);
			server.showMessage(server.getTime() + ": User updated successfully");
			
		}catch(IOException e){
			server.showMessage(server.getTime() + ": Communication errorIO");
		} catch (ClassNotFoundException e) {
			server.showMessage(server.getTime() + ": Communication errorCNF ");
		}
	}
	
	
	/**
	 * Permet afegir un nou usuari.
	 * Rebem l'usuari mitjan�ant oiStream i l'afegim a la base de dades.
	 * Retornem un String (doStream) segons si l'operacio ha estat o no exitosa.
	 */
	public void setNew(){
		
		try{
			oiStream = new ObjectInputStream(sClient.getInputStream());
			User u = (User)oiStream.readObject();
			server.showMessage(server.getTime() + ": New user petition received:\n" + u.getName() + "||" + u.getPassword());
			
			String s = "";
			s = dbOps.addUser(u);
			doStream = new DataOutputStream(sClient.getOutputStream());
			doStream.writeUTF(s);
		}catch(IOException e){
			server.showMessage(server.getTime() + ": Communication errorIO");
		} catch (ClassNotFoundException e) {
			server.showMessage(server.getTime() + ": Communication errorCNF ");
		}
	}
	
	
	/**
	 * Permet comprovar si les dades entrades per al login son correctes o no.
	 * Rebem l'usuari (oiStream) que s'ha pretes loguejar. Comprovem les dades amb la base de dades i 
	 * retornem un string (doStream) segons si l'operacio ha estat o no exitosa.
	 */
	public void checkUser(){
		try {
			oiStream = new ObjectInputStream(sClient.getInputStream());
			User u = (User)oiStream.readObject();
			server.showMessage(server.getTime() + ": login petition received:\n" + u.getName() + "||" + u.getPassword());
			
			String s = dbOps.checkUser(u);
			doStream = new DataOutputStream(sClient.getOutputStream());
			doStream.writeUTF(s);
			if (s.equals("")){
				server.showMessage(server.getTime() + ": Login Sucessful");
			}
			else{
				server.showMessage(server.getTime() + ": " + s);
			}
		} catch (IOException e) {
			server.showMessage(server.getTime() + ": Communication error IOEX");
			
		} catch (ClassNotFoundException e) {
			server.showMessage(server.getTime() + ": Communication error CNF");
		}
		
	}
	
	/**
	 * Permet obtenir el ranking de la base de dades
	 * Rebem un string amb el mode de joc (diStream)
	 * Obtenim el ranking d'aquest mode de joc de la base de de dades.
	 * Retornem una linked list amb el ranking (ooStream).
	 */
	public void getRank(){
		try {
			
			diStream = new DataInputStream(sClient.getInputStream());
			String mode = diStream.readUTF();
			LinkedList <User> list = dbOps.getRanking(mode);
			ooStream = new ObjectOutputStream(sClient.getOutputStream());
			if (list == null || list.size() == 0){
				server.showMessage(server.getTime() + ": No data found");
				ooStream.writeObject(list);
			}
			else{
				ooStream.writeObject(list);
				server.showMessage(server.getTime() + ": Ranking sent successfully");
				
			}
		} catch (IOException e) {
			server.showMessage(server.getTime() + ": Communication error IOEX");
			
		}
	}
	
	/**
	 * Desactivem servidor.
	 */
	public void stopListening(){
		this.active = false;
	}

}
