package network;

import java.io.IOException;
import java.net.ServerSocket;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import controller.ConnectionController;

/**
 * Aquesta classe s'encarrega d'establir una connexi� de tipus servidor que pugui rebre peticions de client.
 *
 */
public class Server{
	private ServerSocket sServer;
	private int port;
	private WaitConnectionThread wct;
	private ConnectionController c;
	

	/**
	 * Inicialitza al port per defecte
	 * @param c Controlador per poder enviar informacio a la vista.
	 */
	public Server(ConnectionController c){
		this.port = 55555;
		this.c = c;
	}
	
	/**
	 * s'encarrega d'obtenir el temps actual
	 * @return Temps actual
	 */
	public String getTime(){
		DateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
		Date time = new Date();
		return dateFormat.format(time);
	}
	
	/**
	 * Permet obrir la connexio de tipus Servidor:
	 * 1. creem el server socket del Servidor
	 * 2.- Creem un nou thread que escoltar� peticions de client, rebra la info, i tancar� la petici� continuament
	 * 
	 */
	public void connect(){
		try {
			sServer = new ServerSocket(this.port);
			wct = new WaitConnectionThread(this, sServer);
			new Thread(wct).start();
		} catch (IOException e) {
			System.out.println("Connect Server Error!");
		}
	}
	
	
	/**
	 * Permet tancar la connexio de tipus Servidor:
	 * 1. Aturem el thread creat
	 * 2.- Tanquem el server socket
	 * 
	 */
	public void disconnect(){
		try {
			sServer.close();
		} catch (IOException e) {
			System.out.println("Close Server Error!");
		}
		c.showMessage(getTime()+": Server closed.\n");
	}
	
	/**
	 * La informaci� que envii el client al servidor (escoltada pel thread) l'enviem 
	 * al controlador perqu� ho mostri a la vista
	 */
	public void showMessage(String s){
		c.showMessage(s);
	}
	
	public void setController(ConnectionController c){
		this.c = c;
	}
	
}
