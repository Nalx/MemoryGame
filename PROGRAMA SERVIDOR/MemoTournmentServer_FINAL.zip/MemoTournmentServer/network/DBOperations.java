package network;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.LinkedList;

import model.User;
import model.UserManagement;
import controller.ConnectionController;
import controller.OptionController;

/**
 * Aquesta classe permet interaccionar amb la base de dades fent us de la classe DBConnection.
 * Per tant, aquesta es una classe de connexio a nivell mes alt.
 */
public class DBOperations {
	
	private DBConnection c;
	private UserManagement um;
	private OptionController oController;
	private ConnectionController cController;
	
	
	/**
	 * El constructor inicialitza els parametres.
	 * @param contr Controlador que permetra mostrar informacio per patalla.
	 */
	public DBOperations(OptionController contr){
		c = new DBConnection();
		um = new UserManagement(new LinkedList<User>());
		this.oController = contr;
	}
	
	public DBOperations(){
		
		um = new UserManagement(new LinkedList<User>());
		c = new DBConnection();
	}
	
	
	/**
	 * Permt comprovar que la connexio a la base de dades es correcta
	 * 
	 * @throws SQLException Si la connexio es incorrecta
	 * @throws ClassNotFoundException Si la connexio es incorrecta
	 */
	public void test() throws SQLException, ClassNotFoundException{
		c.connect();
		c.disconnect();
	}

	/**
	 * Permet canviar els valors per defecte de DBOperations
	 * @param db Base de dades
	 * @param user Nom usuari
	 * @param password Password usuari
	 * @param port Port on es realitzara la connexio
	 */
	public void setValues(String db, String user, String password, int port){
		c.setValues(db, user, password, port);
	}
	
	/**
	 * Permet comprovar si l'usuari existeix o no a la base de dades.
	 * @param u Usuari a comprovar.
	 * @return Retorna la contrasenya de l'usuari en questio.
	 */
	public String checkUser(User u){
		LinkedList<User> list = new LinkedList<User>();
		list = getUsersList();
		um.setUsers(list);
		return  um.checkPassword(u);	
	}
	
	
/**
 * Permet afegir un usuari nou a la base de dades.
 * @param u Usuari a inserir
 * @return retorna un String depenent de si la insercio ha estat correcta o no.
 */
	public String addUser(User u){		
		String s = "";
		try{
			
			c.connect();
			um.setUsers(getUsersList());
			s = um.addUser (u);
			if( s.equals("")){
				c.insert("INSERT INTO player (name,password) VALUES('" + u.getName() + "','" + u.getPassword() + "')");
			}
			else{
			}
			System.out.println("4");
		}catch(SQLException e){
		}catch(ClassNotFoundException e){
		}
		System.out.println("5");
		return s;
	}

	/**
	 *  Insereix una nova puntuaci per a un jugador concret
	 * @param u Usuari a actualitzar.
	 * @return String que indica si hi ha hagut algun error a l'actualitzacio de dades.
	 */
	public String update(User u){
		
		String s = "";
		try{
		
			
			c.connect();
			c.insert("INSERT INTO history (name,score,mode) VALUES('" + u.getName() + "'," + u.getScore() 
					+",'" + u.getPassword() +"')");
		}catch(SQLException e){
			s = "Couldn't connect with server!";
		}catch(ClassNotFoundException e){
			s = "Couldn't connect with server!";
		}
		return s;
	}

/**
 * S'encarrega d'obtenir el ranking d'un mode determinat.
 * @param mode mode de joc del que es requereix el ranking.
 * @return Linked list amb els jugadors i les seves puntuacions.
 */
	public LinkedList<User> getRanking(String mode){
		LinkedList<User> l = new LinkedList<User>();
		
		try {
			c.connect();
			ResultSet consulta;
			consulta = c.select("SELECT name, MAX(score) FROM history where mode like '"+ mode + "' Group by name Order by MAX(score) desc");
			while(consulta.next()){ // Mentre encara hi hagi files en el resiultat del select...
				l.add(new User((String)consulta.getObject("name"), "", (Integer) consulta.getObject("MAX(score)")));
			}
			
			if (l.size() == 0){
				return null;
			}
			else{
				for (int i = 0; i < l.size(); i++){
					System.out.println(l.get(i).getName() + "||" + l.get(i).getScore());
				}
				return l;
			}
			
		
		} catch (SQLException e) {
			oController.showMessage("Couldn't get data from databaseSQL");
			
		} catch (ClassNotFoundException e) {
			oController.showMessage("Couldn't get data from databaseCNF");
		}
		
		return l;
		
	}
	
	
	public DBConnection getDBConnection(){
		return this.c;
	}
	
	/**
	 * S'encarrega d'obtenir la llista d'usuaris
	 * @return llista amb els usuaris registrats a la base de dades. 
	 */
	public LinkedList<User> getUsersList() {
		LinkedList<User> l = new LinkedList<User>();
		try {
			c.connect();
			ResultSet consulta;
			
			consulta = c.select("SELECT name, password FROM player");
			while(consulta.next()){ // Mentre encara hi hagi files en el resiultat del select...
				l.add(new User((String)consulta.getObject("name"), (String)consulta.getObject("password"), -1));
			}
		} catch (SQLException e) {
			oController.showMessage("Couldn't get data from database");
		}catch(ClassNotFoundException e){
			oController.showMessage("Couldn't get data from database");
		}
		return l;
		
	}
	
	
	/**
	 * S'encarrega d'obtenir tot el registre de puntuacions d'un jugador per a un mode determinat.
	 * @param name nom del jugador/usuari.
	 * @param mode mode de joc
	 * @return Linked List amb les puntuacions del jugador ordenades segons antiguitat.
	 */
	public LinkedList<Integer> getUserGraphList (String name, String mode){
		LinkedList<Integer> l = new LinkedList<Integer>();
		try {
			c.connect();
			ResultSet consulta;
			System.out.println(name+"@"+mode);
			consulta = c.select("SELECT score FROM history where name like '"+name +"' AND mode like '"+ mode + "' order by id");
			
			while(consulta.next()){ // Mentre encara hi hagi files en el resiultat del select...
				l.add(new Integer ((Integer)consulta.getObject("score")));
			}
			
			if (l.size() == 0){
				oController.showMessage("No data found");
				return null;
			}
			else{
				oController.showMessage("Graph data obtained successfully");
				for (int i = 0; i < l.size(); i++){
					System.out.print("||" + l.get(i) + "||");
				}
				return l;
			}
		} catch (SQLException e) {
			oController.showMessage("Couldn't get data from databaseSQL");
		}catch(ClassNotFoundException e){
			oController.showMessage("Couldn't get data from databaseCNF");
		}
		return l;

	}
}
