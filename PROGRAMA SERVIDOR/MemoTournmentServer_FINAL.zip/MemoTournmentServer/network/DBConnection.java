package network;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
/**
 * Aquesta classe implementa la connexi� a nivell m�s baix 
 * del programa servidor a una base de dades mitjan�ant JDBC
 *
 */

public class DBConnection {
	private String url = "jdbc:mysql://localhost";
	private String db;
	private String user;
	private String password;
	private int port;
	static Connection connexio = null;
	
	private static final int STPORT = 3306;
	private static final String STUSER = "root";
	private static final String STPASSWORD = "root";
	private static final String STDB = "dpo";
	
	
	static Statement s;
	
	/**
	 * Al constructor inicialitzem els parametres de port, usuari, password i base de dades amb les dades per defecte.
	 */
	
	public DBConnection(){
		this.port = STPORT;
		this.user = STUSER;
		this.password = STPASSWORD;
		this.db = STDB;
		this.url = "jdbc:mysql://localhost:"+port+"/"+db;
		
	}
	
	/**
	 * Permet modificar les dades per defecte de la connexio a la base de dades
	 * @param db nom de la base de dades a que ens connectem
	 * @param user nom d'usuari
	 * @param password password de l'usuari
	 * @param port port de connexio
	 */
	public void setValues(String db, String user, String password, int port){
		this.user = user;
		this.password = password;
		this. port = port;
		this.db = db;
		this.url = "jdbc:mysql://localhost:"+port+"/"+db;
	}
	
	
	/**
	 * Permet connectar-nos a la base de dades.
	 * 
	 * 
	 * @throws SQLException Si no es pot generar la connexio.
	 * @throws ClassNotFoundException En cas que la connexio rebuda per DriverManager sigui erronia.
	 */
	
	public void connect () throws SQLException, ClassNotFoundException{
		Class.forName("com.mysql.jdbc.Connection");
		connexio = (Connection) DriverManager.getConnection(url, user, password);
		if (connexio != null){
			System.out.println("Connexio a BD: "+db+" OK!");
		}
		else{
			System.out.println("No s'ha pogut connectar a la BD!");
		}
	}
	
	public void showValues(){
		System.out.println("\n\nVALUES SET--> \nUser:" + this.user + "\nPassword:" + this.password + "\nPort:" + this.port + "\nDB:" + this.db);
	}
	
	
	/**
	 * Tanquem la connexio oberta anteriorment.
	 * @throws SQLException En cas que no es trobi la connexio oberta a tancar.
	 */
	public void disconnect() throws SQLException{
		connexio.close();
	}
	
	
	
	/**
	 * Permet realitzar una sentencia de insercio a la base de dades
	 * @param sentencia String amb la sentencia a executar
	 * @throws SQLException En cas que la sentencia sigui erronia
	 */
	public void insert(String sentencia) throws SQLException{
		s = (Statement) connexio.createStatement();
		s.executeUpdate(sentencia);
		System.out.println("INSERT QUERY OK!");
	}
	
	
	/**
	 * Permet realitzar una sentencia de actualitzacio a la base de dades
	 * @param sentencia String amb la sentencia a executar
	 * @throws SQLException En cas que la sentencia sigui erronia
	 */
	
	public void update(String sentencia) throws SQLException{
		s = (Statement) connexio.createStatement();
		s.executeUpdate(sentencia);
		System.out.println("UPDATE QUERY OK!");
	
	}
	
	/**
	 * Permet realitzar una sentencia de eliminacio a la base de dades
	 * @param sentencia String amb la sentencia a executar
	 * @throws SQLException En cas que la sentencia sigui erronia
	 */
	public void delete(String sentencia) throws SQLException{
		
		s = (Statement) connexio.createStatement();
		s.executeUpdate(sentencia);
		System.out.println("DELETE QUERY OK!");
		
	
	}
	
	/**
	 * Permet realitzar una sentencia de seleccio a la base de dades
	 * @param sentencia String amb la sentencia a executar
	 * @throws SQLException En cas que la sentencia sigui erronia
	 */
	public ResultSet select (String sentencia) throws SQLException{
	    	ResultSet rs = null;
	        s =(Statement) connexio.createStatement();
	        rs = s.executeQuery (sentencia); 
	    	System.out.println("SELECT QUERY OK!");
			return rs;
    }
	
	
}
