package model;

import java.io.Serializable;
/**
 * Aquesta classe conte la informacio d'un usuari: nom, password i puntuacio.
 * La classe implementa Serializable per tal de poder ser enviada mitjan�ant un servidor.
 *
 */
public class User implements Serializable{
	private String name;
	private String password;
	private int score;
	
	
	
	public int getScore() {
		return score;
	}

	public void setScore(int score) {
		this.score = score;
	}

	/**
	 * Constructor de la classe.
	 * @param name Nom de l'usuari
	 * @param password Contrassenya de l'usuari
	 * @param score Puntuaci� de l'usuari.
	 */
	public User(String name, String password, int score) {
		this.name = name;
		this.password = password;
		this.score = score;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
