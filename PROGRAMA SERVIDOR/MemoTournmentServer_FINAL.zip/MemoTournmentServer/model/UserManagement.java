package model;

import java.util.LinkedList;

/**
 * Classe que exerceix de facade dins del package de model. 
 * Conte les operacions relatives a la classe User.
 *
 */

public class UserManagement {
	private LinkedList <User> users;
	
	/**
	 * Constructor
	 * @param users Linked List amb tots els usuaris
	 */
	public UserManagement(LinkedList<User> users) {
		this.users = users;;
	}
	
	
	

	/**
	 * Metode on validem que la contrasenya entrada per al login entrat �s v�lida.
	 * Busquem el login i contrassenya entrats a la linked list d'usuari.
	 * @param u Usuari amb el nom i contrassenya entrats.
	 * @return String amb el missatge d'error corresponent, si existeix, o buit en cas contrari.
	 */
	public String checkPassword(User u) {
		
		boolean ok = false;
				
		for (int i = 0; i < users.size(); i++){
			System.out.println(users.get(i).getName() + " " + users.get(i).getPassword());
		}
		
		for (int i = 0; i < users.size(); i++){
			if (users.get(i).getName().equals(u.getName())){
				if (users.get(i).getPassword().equals(u.getPassword())){
					System.out.println("Hi");
					ok = true;
					break;
				}
				return ("Error! Incorrect Password!");
			}
		}
		if(!ok){
			return ("Error! Inexistent User!");
		}
		return "";
	}
	
	
	/**
	 * Permet comprovar que el nou usuari no existeix a la base de dades actual.
	 * @param u Nou Usuari (nom i contrassenya).
	 * @return String amb missatge d'error, si existeix, o buit, en cas contari. 
	 */
	public String addUser(User u){
		
		
		if (u.getPassword().equals("") || u.getName().equals("")){
			return "User and Password are required!";
		}
		for (int i = 0; i < users.size();i++){
			if (users.get(i).getName().equals(u.getName())){
				return "This username already exists!";
			}
		}
		return "";
		
	}
	

	/**
	 * Metode que permet printar les dades dels usuaris per consola
	 */
	public void showUsers(){
		for (int i = 0; i < users.size(); i++){
			System.out.println(users.get(i).getName() + "\t" + users.get(i).getPassword());
		}
	}
	
	public LinkedList<User> getUsers() {
		return users;
	}


	public void setUsers(LinkedList<User> users) {
		this.users = users;
	}

	
}
