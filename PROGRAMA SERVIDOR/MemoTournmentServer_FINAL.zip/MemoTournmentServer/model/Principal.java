package model;
import javax.swing.SwingUtilities;

import view.CustomConnectionView;
import view.InitialView;
import view.OptionMenu;
import view.ServerWindow;
import controller.ConnectionController;
import controller.OptionController;

/**
 * Classe principal des d'on s'inicialitza el programa
 *
 */
public class Principal {
	
	/**
	 * procediment est�tic des d'on s'inicialitza el programa
	 * Inicialitzem la ServerWindow i hi afegim les vistes corresponents.
	 * Relacionem les vistes amb els seus corresponents controladors.
	 * Iniciem el programa mostrant la vista inicial: InitialView.
	 * @param args En principi, no li passarem parametres al metode main
	 */
	public static void main (String args []){
		SwingUtilities.invokeLater(new Runnable() {
		
			public void run() {
			
				
				
				//VISTA-CONTROLADOR
				ServerWindow sWindow = new ServerWindow();
				
				OptionMenu omView = new OptionMenu();
				OptionController oController = new OptionController(omView, sWindow);
				omView.setController(oController);
				sWindow.addOptionMenu(omView);
				
				
				InitialView iView = new InitialView();
				sWindow.addInitialView(iView);
				
				
				CustomConnectionView ccView = new CustomConnectionView();
				ConnectionController ccController = new ConnectionController(sWindow, ccView, iView, omView);
				
				ccView.setController(ccController);
				iView.setController(ccController);
				
				
				
				sWindow.addCustomConnectionView(ccView);
				//----------------------------------------------------------
				
				sWindow.setVisible(true);
				sWindow.showInitialView();
		
			
			}
		
		});
	}
}
