package view;

import java.util.LinkedList;

import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

import model.User;
import controller.OptionController;
/**
 * Aquesta classe constitueix la vista del Ranking del programa servidor.
 * La vista es un panell i, per tant, hereta de JPanel.
 * Els principals components d'aquesta vista son: una JTextarea on es mostrara el propi Ranking,
 * i un boto per a tornar enrere.
 *
 */


public class Ranking extends JPanel{

	private JTextArea jtaText;
	private JScrollPane jspText;
	
	private JButton jbBack;
	
	
	/**
	 * El constructor inicialitza la vista i rep per parametre el titol de la mateixa.
	 * @param title Titol de la vista.
	 */
	public Ranking(String title){
		jtaText = new JTextArea();
		jtaText.setEditable(false);
		jtaText.setVisible(true);
		
		jspText = new JScrollPane(jtaText);
		
		jbBack = new JButton("Go Back");
		
		JLabel jlTitle = new JLabel(title);
		
		
		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		this.add(jlTitle);
		this.add(jspText);
		this.add(jbBack);
	}
	
	/**
	 * Lliga el boto jbBack amb el controllador de tipus OptionController.
	 * @param c Controlador que escoltara el boto.
	 */
	
	public void setController(OptionController c){
		jbBack.addActionListener(c);
		jbBack.setActionCommand("Back");
	}
	
	
	/**
	 * Mostra el ranking per pantalla a partir d'una LinkedList d'usuaris.
	 * @param list LinkedList d'usuaris ordenats per puntuaci�.
	 */
	public void setRankingText(LinkedList<User> list){
		String s = "";
		for (int i = 0; i < list.size(); i++){
			s += i+1 + ". " + list.get(i).getName() +"	"+ list.get(i).getScore() + "\n";
		}
		jtaText.setText(s);
	}
}
