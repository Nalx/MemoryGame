package view;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import controller.OptionController;

/**
 * Aquesta classe constitueix la vista deconnexi� amb el servidor. 
 * Es tracta d'un panell, per tant, hereta de JPanel.
 * 
 * Els elements principals s�n: una JTextArea on rebrem el feedback de les connexions dels clients.
 * Dues JTextFields per entrar el nom i password d'un nou usuari i un bot� per a validar-ho.
 * Dues JTextfields per entrar el nom d'un usuari i un mode de joc i un boto per a mostrar el 
 * grafic corresponent.
 * 
 * Una textfield per introduir el mode de joc i un boto per mostrar-ne el Ranking corresponent.
 *
 */
public class OptionMenu extends JPanel{
	
	private JTextField jtfNew;
	private JTextField jtfPass;
	private JButton jbNew;
	private JButton jbRank;
	private JButton jbGraph;
	private JTextField jtfName;
	private JTextArea jtaText;
	private JScrollPane jspText;
	private JTextField jtfModeR;
	private JTextField jtfModeG;
	
	
	/**
	 * Al constructor inicialitzem els elements de la vista.
	 * No rebem par�metres.
	 */
	public OptionMenu(){
		
		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		
		
		jtaText = new JTextArea();
		jtaText.setEditable(false);
		jtaText.setBackground(Color.BLACK);
		jtaText.setForeground(Color.GREEN);
		jspText = new JScrollPane(jtaText);
		jspText.setBorder(BorderFactory.createTitledBorder("Command Window"));
		
		JLabel jlNew = new JLabel("User Name:");
		jtfNew = new JTextField(15);
		JLabel jlPass = new JLabel("Password:");
		jtfPass = new JTextField(15);
		jbNew = new JButton ("New Local User");
		JPanel jpNewUser = new JPanel(new GridLayout(3,2));
		jpNewUser.add(jlNew);
		jpNewUser.add(jtfNew);
		jpNewUser.add(jlPass);
		jpNewUser.add(jtfPass);
		jpNewUser.add(jbNew);
		jpNewUser.setBorder(BorderFactory.createTitledBorder("New User"));
		jpNewUser.setMinimumSize(new Dimension(280,150));
		jpNewUser.setMaximumSize(new Dimension(280,150));
		
		JPanel jpRank = new JPanel(new GridLayout(2,2));
		JLabel jlMode = new JLabel("Game Mode:");
		jbRank = new JButton("Show Ranking");
		jtfModeR = new JTextField(15);
		jpRank.add (jlMode);
		jpRank.add(jtfModeR);
		jpRank.add(jbRank);
		jpRank.setMinimumSize(new Dimension(280,150));
		jpRank.setMaximumSize(new Dimension(280,150));
		jpRank.setBorder(BorderFactory.createTitledBorder("Ranking"));
		
		
		JLabel jlName = new JLabel("User Name: ");
		jtfName = new JTextField(15);
		jtfModeG = new JTextField(15);
		jbGraph = new JButton("Show Graph");
		JPanel jpGraph = new JPanel(new GridLayout(3,2));
		jpGraph.add(jlName);
		jpGraph.add(jtfName);
		jpGraph.add(new JLabel ("Game Mode:"));
		jpGraph.add(jtfModeG);
		jpGraph.add(jbGraph);
		jpGraph.setBorder(BorderFactory.createTitledBorder("Graph"));
		jpGraph.setMinimumSize(new Dimension(280,150));
		jpGraph.setMaximumSize(new Dimension(280,150));
		
		this.add(jspText);
		this.add(jpNewUser);
		this.add(jpGraph);
		this.add(jpRank);
	}
	
	
	public String getCommandText(){
		return jtaText.getText();
	}
	
	public void setCommandText(String s){
		jtaText.setText(s);
	}
	
	/**
	 * Linka els botons amb un controlador de tipus OptionController
	 * @param c Controlador que escoltara els botons de la vista.
	 */
	public void setController(OptionController c){
		jbGraph.setActionCommand("Graph");
		jbGraph.addActionListener(c);
		
		jbRank.setActionCommand("Ranking");
		jbRank.addActionListener(c);
		
		jbNew.setActionCommand("User");
		jbNew.addActionListener(c);
	}
	
	public String getNewUser(){
		return jtfNew.getText();
	}
	public String getNewPassword(){
		return jtfPass.getText();
	}
	public String getGraphUser(){
		return jtfName.getText();
	}
	
	public String getTypedModeRank(){
		return jtfModeR.getText();
	}
	public String getTypedModeGraph(){
		return jtfModeG.getText();
	}
}


