package view;

import java.awt.Dimension;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JPanel;

import controller.ConnectionController;

/**
 * Aquesta vista constitueix allo que primer veura l'usuari a l'iniciar el programa servidor.
 * Es tracta d'un panell i, per tant, hereta de JPanel.
 * En aquesta vista unicament es mostren dos botons, un per iniciar la connexio per defecte i un altre per iniciar una 
 * connexio personalitzada.
 *
 *
 */
public class InitialView extends JPanel {
	private JButton jbDefault;
	private JButton jbCustomized;
	
	/**
	 * Al constructor inicialitzem els elements de la vista.
	 * No rep parametres
	 */
	
	public InitialView(){
		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		this.setBorder(BorderFactory.createTitledBorder("DBConnection"));
		
		this.add(Box.createRigidArea(new Dimension(200, 100)));
		
		jbDefault = new JButton("Default Connexion");
		jbDefault.setAlignmentX(CENTER_ALIGNMENT);
		jbDefault.setMinimumSize(new Dimension(200,100));
		jbDefault.setMaximumSize(new Dimension(200,100));
		
		jbCustomized = new JButton("Customized Connexion");
		jbCustomized.setMinimumSize(new Dimension(200,100));
		jbCustomized.setMaximumSize(new Dimension(200, 100));
		jbCustomized.setAlignmentX(CENTER_ALIGNMENT);
		
		this.add(jbDefault);
		this.add(jbCustomized);
	}
	
	/**
	 * Relacionem els botons amb el seu corresponent Conttrolador.
	 * @param c Controlador que escoltara els esdeveniments generats pels botons en questio.
	 */
	public void setController(ConnectionController c){
		jbDefault.addActionListener(c);
		jbDefault.setActionCommand("Default");
		
		jbCustomized.addActionListener(c);
		jbCustomized.setActionCommand("Custom");
		
	}
}
