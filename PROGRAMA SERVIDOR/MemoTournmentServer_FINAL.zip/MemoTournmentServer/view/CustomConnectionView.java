package view;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import controller.ConnectionController;

/**
 * Aquesta classe constitueix la vista per configurar una connexio personalitzada.
 * 
 * Els elements mes importants son els JTextfields on canviar les dades de connexio per defecte i,
 * els botons de connactar i de reestablir els camps per defecte.
 *
 */

public class CustomConnectionView extends JPanel{

	private JTextField jtfUser;
	private JTextField jtfPassword;
	private JTextField jtfDB;
	private JTextField jtfPort;
	
	private JButton jbRestore;
	
	private JButton jbConnect;
	
	private static final String PORT = "3306";
	private static final String USER = "root";
	private static final String PASSWORD = "root";
	private static final String DB = "dpo";
	
	
	/**
	 * Al constructor inicialitzem els elemennts de la vista.
	 * No rep parametres.
	 */
	public CustomConnectionView(){
		this.setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		
		
		
		jtfDB = new JTextField(15);
		JLabel jlDB = new JLabel("Database");
		JPanel jpDB = new JPanel(new FlowLayout());
		
		jtfPassword = new JTextField(15);
		JLabel jlPassword = new JLabel("Password");
		JPanel jpPa = new JPanel(new FlowLayout());
	
		
		jtfPort = new JTextField(15);
		JLabel jlPort = new JLabel("Port");
		JPanel jpPo = new JPanel(new FlowLayout());

		
		jtfUser = new JTextField(15);
		JLabel jlUser = new JLabel("User");
		JPanel jpUs = new JPanel(new FlowLayout());

		
		jbConnect = new JButton("Start Connection!");
		jbRestore = new JButton("Restore");
		
		JPanel jpOptions = new JPanel(new GridLayout(4,2));
		jpOptions.add(jlDB);
		jpOptions.add(jtfDB);

		jpOptions.add(jlPort);
		jpOptions.add(jtfPort);
		jpOptions.add(jlUser);
		jpOptions.add(jtfUser);
		jpOptions.add(jlPassword);
		jpOptions.add(jtfPassword);
		
		jpOptions.setMinimumSize(new Dimension(250,200));
		jpOptions.setMaximumSize(new Dimension(250,200));
		jpOptions.setBorder(BorderFactory.createTitledBorder("Options"));
		
		
		JPanel jpButtons = new JPanel(new GridLayout(2,1));
		jpButtons.add(jbRestore);
		jpButtons.add(jbConnect);
		jpButtons.setMinimumSize(new Dimension(200, 100));
		jpButtons.setMaximumSize(new Dimension(200,100));
		
		
		this.add(Box.createRigidArea(new Dimension(200, 80)));
		this.add(jpOptions);
		this.add(Box.createRigidArea(new Dimension(200, 40)));
		this.add(jpButtons);
		
		
		setDefaultValues();
	}
	
	
	/**
	 * Estabeix els valors per defecte als JTextFields.
	 */
	public void setDefaultValues(){
		setTypedDB(DB);
		setTypedPort(PORT);
		setTypedPassword(PASSWORD);
		setTypedUser(USER);
	}
	
	public int getIntPort(){
		return Integer.parseInt(jtfPort.getText());
	}
	
	public void setTypedDB(String s){
		jtfDB.setText(s);
	}
	
	
	public void setTypedPort(String s){
		jtfPort.setText(s);
	}
	
	public void setTypedUser(String s){
		jtfUser.setText(s);
	}
	
	public void setTypedPassword(String s){
		jtfPassword.setText(s);
	}
	
	public String getTypedDB(){
		return jtfDB.getText();
	}

	
	public String getTypedPort(){
		return jtfPort.getText();
	}
	
	public String getTypedPassword(){
		return jtfPassword.getText();
	}
	
	public String getTypedUser(){
		return jtfUser.getText();
	}

	
	/**
	 * Lliga els botons amb el seu corresponent Controlador.
	 * @param c Controlador que escoltara els botons de Restore i Connect.
	 */
	public void setController(ConnectionController c){
		jbRestore.setActionCommand("Restore");
		jbRestore.addActionListener(c);
		
		jbConnect.setActionCommand("Connect");
		jbConnect.addActionListener(c);
	}
	
}
