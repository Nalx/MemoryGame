package view;

import java.awt.BorderLayout;
import java.util.LinkedList;

import javax.swing.JButton;
import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

import controller.OptionController;

/**
 * Vista encarregada de mostrar un grafic amb l'evolucio d'un jugador.
 * Es tracta d'un panell i, per tant, hereta de JPanel.
 * 
 * En aquesta vista nomes trobarem el panell amb el grafic i un boto que ens permetra tornar enrere.
 * @author edu
 *
 */

public class GraficArrays extends JPanel {

	
	private JButton jbBack;
	JPanel graficVisualisation;
	private LinkedList<Integer> ll;
	String name;
	
	public GraficArrays(){
		
	}
	
	public LinkedList <Integer> getList(){
		return this.ll;
	}
	
	public void setList(LinkedList <Integer> l){
		this.ll = l;
	}
	
	public void setName(String name){
		this.name = name;
	}
	
	/**
	 * Constructor on inicialitzem els elements de la vista.
	 * @param l llista amb les puntuacions del jugador
	 * @param name nom del jugador.
	 */
	public GraficArrays(LinkedList <Integer> l, String name) {
		System.out.println(l.size());
		this.name = name;
		
		this.ll = l;
		init(this.ll);
		
		
		
		this.setLayout(new BorderLayout());
		jbBack = new JButton("Go Back");
		this.add(jbBack, BorderLayout.SOUTH);
		this.add(graficVisualisation, BorderLayout.CENTER);
	}
	
	/**
	 * metode on generem la vista del grafic.
	 * 
	 * Afegim cada valor de puntacio al line_chart_dataset.
	 * 
	 * Creem un chart on li passem el titol del grafic, els noms de les variables de cada eix,
	 * el line_chart_dataset i la orientacio del grafic, entre d'altres.
	 * 
	 * Creem un ChartPanel on hi afegim el chart i el mostrem.
	 * 
	 * @param l Linked list amb les puntuacions del jugador.
	 */
	
	public void init(LinkedList<Integer> l){
		graficVisualisation = new JPanel();
		
		DefaultCategoryDataset line_chart_dataset = new DefaultCategoryDataset();
		
		System.out.println(l.size());
		for (int i = 0; i < l.size(); i++) {
			line_chart_dataset.addValue(l.get(i),"Points", "Game"+i);
		}
		
		JFreeChart chart = ChartFactory.createLineChart("Score Graph " + name, "Games","points",line_chart_dataset, PlotOrientation.VERTICAL,true,true,false);
		ChartPanel chartPanel = new ChartPanel(chart);
		graficVisualisation.add(chartPanel);
		
	}
	
	
	/**
	 * Relaciona el boto de retorn amb el seu controlador corresponent.
	 * 
	 * @param c Controlador que escoltara el boto de tornar enrere.
	 */
	public void setController(OptionController c){
		jbBack.setActionCommand("Back");
		jbBack.addActionListener(c);
	}
	
}
