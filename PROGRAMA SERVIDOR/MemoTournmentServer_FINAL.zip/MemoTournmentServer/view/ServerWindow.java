package view;
import java.awt.CardLayout;

import javax.swing.JFrame;
/**
 * Aquesta classe es la finestra del Servidor. Per tant, hereta de JFrame. 
 * La finestra consta d'un cardLayout on hi guardarem les diferents vistes del Servidor.
 * En aquesta classe podrem afegir vistes al cardLayout i mostrar-les a la finestra quan es desitgi.
 *  
 */


public class ServerWindow extends JFrame{
	
	private CardLayout cLayout;
	
	/**
	 *  Hi declarem el cardLayout i establim mida i altres caracteristiques de la finestra.
	 *  El constructor no rep parametres.
	 */
	public ServerWindow(){
		cLayout = new CardLayout();
		this.setLayout(cLayout);
		setSize(800, 600);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		setTitle("Server");
		
	}
	
	
	/**
	 * Afegeix al cardLayout la vista inicial, la qual rep per parametre.
	 * 
	 * @param iView Vista inicial, la que es mostrara nomes obrir la finestra.
	 */
	public void addInitialView(InitialView iView){
		getContentPane().add(iView, "InitialView");
	}
	
	/**
	 * Mostra la vista inicial.
	 */
	public void showInitialView(){
		cLayout.show(getContentPane(), "InitialView");
	}
	
	
	/**
	 * Afegeix al cardLayout la vista de connexio personalitzada, la qual rep per parametre.
	 * 
	 * @param ccView Vista de Connexio personalitzada.
	 */
	
	public void addCustomConnectionView(CustomConnectionView ccView){
		getContentPane().add(ccView,"CustomConnectionView");
	}
	
	/**
	 * Mostra la vista de connexio personalitzada.
	 */
	public void showCustomConnectionView(){
		cLayout.show(getContentPane(), "CustomConnectionView");
	}
	
	
	/**
	 * Afegeix al cardLayout la vista de Conexio del servidor, la qual rep per parametre.
	 * 
	 * @param omView Vista de Connexio del servidor.
	 */
	public void addOptionMenu(OptionMenu omView){
		getContentPane().add(omView,"OptionMenu");
	}
	
	/**
	 * Mostra la vista de connexio personalitzada.
	 */
	public void showOptionMenu(){
		cLayout.show(getContentPane(), "OptionMenu");
	}
	
	
	/**
	 * Afegeix al cardLayout la vista del Grafic, la qual rep per parametre.
	 * 
	 * @param gView vista del Grafic.
	 */
	public void addGraph(GraficArrays gView){
		getContentPane().add(gView, "Graph");
	}
	
	/**
	 * Mostra a vista del grafic.
	 */
	public void showGraph(){
		cLayout.show(getContentPane(), "Graph");
	}
	
	
	/**
	 * Afegeix al cardLayout la vista del Ranking, la qual rep per parametre.
	 * 
	 * @param rView vista del Ranking.
	 */
	public void addRanking(Ranking rView){
		getContentPane().add(rView, "Ranking");
	}
	
	/**
	 * Mostra la vista del Ranking.
	 */
	public void showRanking(){
		cLayout.show(getContentPane(), "Ranking");
	}
	
	
}
