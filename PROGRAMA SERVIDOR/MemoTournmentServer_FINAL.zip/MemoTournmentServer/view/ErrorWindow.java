package view;

import javax.swing.JOptionPane;

/**
 * Aquesta classe mostra un JOptionpane amb un missatge d'error.
 *
 */
public class ErrorWindow extends JOptionPane {
	
	public ErrorWindow(){
		
	}
	
	/**
	 * Mostra un JOptionPane amb el missatge d'error que rep.
	 * @param message Missatge a mostrar.
	 */
	public static void show(String message){
		JOptionPane.showMessageDialog(null,message, "Error Window", 1);
	}
}
